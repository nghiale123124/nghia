﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


//them các thư viện

using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace Do_an_mo_hinh_3_lop.DAL
{
    class Providers
    {
        // B1: Khai Báo Biến SqlConnection là ketnoi
        public SqlConnection conn;

        //B2 :tạo kết nối vơi CSDL
        public bool Connect()
        {
            string connectionStrings = ConfigurationManager.ConnectionStrings["ConnectStr"].ConnectionString.ToString();
            conn = new SqlConnection(connectionStrings);

            //kiểm tra kết nối và các điều kiện kiểm tra kết nối
            if ((conn.State == ConnectionState.Broken) || (conn.State == ConnectionState.Closed))
            {
                conn.Open();
                return true;

            }
            else
            {
                return false;
            }
        }   // kết thúc phần ketnoi  

        internal int ExecuteNonQuery(string[] queryOrSpName, string[] parameters, object[] values, bool isStored)
        {
            throw new NotImplementedException();
        }

        public void DisConnect()
        {
            conn.Close();// dóng kết nối
            conn.Dispose();
        }// kết thúc DisConnect 


        // B3: tạo các phương thức của sqlCommand

        //=============================================

        //Khai báo hàm thực thi đối với SqlCommand
        //- hàm có 4 tham số truyền vào 
        //- queryOrSpName : Tham số truyền vào câu lệnh SQL hoặc tên của Stored Procedure
        //- Parameters : Mảng chứa các tham số của câu lệnh SQL hoặc tên của Stored Procedure
        //- Values : Mảng chứa các giá trị truyền vào cho các tham số của câu lệnh SQL hoặc tên của Stored Procedure
        //- isStored : True là Stored Proedure ; false là câu lệnh của SQl  ++++++

        public SqlCommand Command(string queryOrSpName, string[] Parameters, object[] Values, bool isStored)
        {
            SqlCommand cmd = new SqlCommand(queryOrSpName, conn);
            if (isStored)
            {
                cmd.CommandText = queryOrSpName;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
            }
            if (Parameters != null)
            {
                for (int i = 0; i < Parameters.Length; i++)
                {
                    cmd.Parameters.AddWithValue(Parameters[i], Values[i]);
                }
            }
            return cmd;

        }//kết thúc Command

        //=============================================

        //Khai bao hàm thực thi phương thức ExecuteReader của đối tượng SqlCommand
        //- hàm có 4 tham số truyền vào 
        //- queryOrSpName : Tham số truyền vào câu lệnh SQL hoặc tên của Stored Procedure
        //- Parameters : Mảng chứa các tham số của câu lệnh SQL hoặc tên của Stored Procedure
        //- Values : Mảng chứa các giá trị truyền vào cho các tham số của câu lệnh SQL hoặc tên của Stored Procedure
        //- isStored : True là Stored Proedure ; false là câu lệnh của SQl  ++++++

        public SqlDataReader ExecuteReader(string queryOrSpName, string[] Parameters,object[] Values,bool isStored)
        {
            SqlDataReader reader = Command(queryOrSpName, Parameters, Values, isStored).ExecuteReader();
            DisConnect();
           return reader;
        }// kêt thúc Phương thức ExecuteReader sử dụng hàm SqlDataReader(chỉ đọc 1 lần )

        //=============================================

        //Khai bao hàm thực thi phương thức ExecuteNonQuery của đối tượng SqlCommand
        //- hàm có 4 tham số truyền vào 
        //- queryOrSpName : Tham số truyền vào câu lệnh SQL hoặc tên của Stored Procedure
        //- Parameters : Mảng chứa các tham số của câu lệnh SQL hoặc tên của Stored Procedure
        //- Values : Mảng chứa các giá trị truyền vào cho các tham số của câu lệnh SQL hoặc tên của Stored Procedure
        //- isStored : True là Stored Proedure ; false là câu lệnh của SQl  ++++++

        public int ExecuteNonQuery(string queryOrSpName, string[] Parameters, object[] Values, bool isStored)
        {
             int rec= Command(queryOrSpName, Parameters, Values, isStored).ExecuteNonQuery();
            DisConnect();
            return rec;
        }//ket thuc Phương Thức ExecuteNonQuery 

        //=============================================

        //Khai bao hàm thực thi phương thức ExecuteScala của đối tượng SqlCommand
        //- hàm có 4 tham số truyền vào 
        //- queryOrSpName : Tham số truyền vào câu lệnh SQL hoặc tên của Stored Procedure
        //- Parameters : Mảng chứa các tham số của câu lệnh SQL hoặc tên của Stored Procedure
        //- Values : Mảng chứa các giá trị truyền vào cho các tham số của câu lệnh SQL hoặc tên của Stored Procedure
        //- isStored : True là Stored Proedure ; false là câu lệnh của SQl  ++++++
        public int ExecuteScala(string queryOrSpName, string[] Parameters, object[] Values)
        {
            int Scalar = (int)Command(queryOrSpName, Parameters, Values, false).ExecuteScalar();
            DisConnect();
            return Scalar;
        }//ket thuc Phương Thức ExecuteScala 

        public DataTable GetData(string queryOrSpName, string[] Parameters, object[] Values, bool isStored)
        {
            //khai báo kiểu dữ liệu DataTable
            DataTable tbl = new DataTable();
            SqlCommand cmd = Command(queryOrSpName, Parameters, Values, isStored);

            //dùng biến đối tượng SqlDataAdapter thực thi lấy dữ liệu
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            //đỗ dữ liệu từ biến kiểu dữ liệu SqlDataAdapter vào biến tbl kiểu dữ liệu DataTable

            da.Fill(tbl);

            DisConnect();
            return tbl;

        }


    }
}
