﻿namespace Do_an_mo_hinh_3_lop.GUI
{
    partial class frmTimnhanvien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_Timmanhanvien = new System.Windows.Forms.TextBox();
            this.dgv_timkiemnhanvien = new System.Windows.Forms.DataGridView();
            this.btn_Timkiem = new System.Windows.Forms.Button();
            this.btn_Thoat = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_timkiemnhanvien)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(80, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã Nhân Viên :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FloralWhite;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(199, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(412, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tìm Nhân Viên theo Mã Nhân Viên";
            // 
            // txt_Timmanhanvien
            // 
            this.txt_Timmanhanvien.Location = new System.Drawing.Point(252, 88);
            this.txt_Timmanhanvien.Name = "txt_Timmanhanvien";
            this.txt_Timmanhanvien.Size = new System.Drawing.Size(277, 30);
            this.txt_Timmanhanvien.TabIndex = 2;
            // 
            // dgv_timkiemnhanvien
            // 
            this.dgv_timkiemnhanvien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_timkiemnhanvien.Location = new System.Drawing.Point(69, 162);
            this.dgv_timkiemnhanvien.Name = "dgv_timkiemnhanvien";
            this.dgv_timkiemnhanvien.RowTemplate.Height = 28;
            this.dgv_timkiemnhanvien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_timkiemnhanvien.Size = new System.Drawing.Size(623, 121);
            this.dgv_timkiemnhanvien.TabIndex = 3;
            this.dgv_timkiemnhanvien.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_timkiemnhanvien_CellContentClick);
            // 
            // btn_Timkiem
            // 
            this.btn_Timkiem.Location = new System.Drawing.Point(574, 80);
            this.btn_Timkiem.Name = "btn_Timkiem";
            this.btn_Timkiem.Size = new System.Drawing.Size(104, 47);
            this.btn_Timkiem.TabIndex = 4;
            this.btn_Timkiem.Text = "Tìm Kiếm";
            this.btn_Timkiem.UseVisualStyleBackColor = true;
            this.btn_Timkiem.Click += new System.EventHandler(this.btn_Timkiem_Click);
            // 
            // btn_Thoat
            // 
            this.btn_Thoat.Location = new System.Drawing.Point(332, 339);
            this.btn_Thoat.Name = "btn_Thoat";
            this.btn_Thoat.Size = new System.Drawing.Size(104, 47);
            this.btn_Thoat.TabIndex = 5;
            this.btn_Thoat.Text = "Thoát";
            this.btn_Thoat.UseVisualStyleBackColor = true;
            this.btn_Thoat.Click += new System.EventHandler(this.btn_Thoat_Click);
            // 
            // frmTimnhanvien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(776, 401);
            this.Controls.Add(this.btn_Thoat);
            this.Controls.Add(this.btn_Timkiem);
            this.Controls.Add(this.dgv_timkiemnhanvien);
            this.Controls.Add(this.txt_Timmanhanvien);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Blue;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmTimnhanvien";
            this.Text = "Tìm Nhân Viên";
            this.Load += new System.EventHandler(this.frmTimnhanvien_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_timkiemnhanvien)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_Timmanhanvien;
        private System.Windows.Forms.DataGridView dgv_timkiemnhanvien;
        private System.Windows.Forms.Button btn_Timkiem;
        private System.Windows.Forms.Button btn_Thoat;
    }
}