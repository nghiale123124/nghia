﻿using Do_an_mo_hinh_3_lop.BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Do_an_mo_hinh_3_lop.GUI
{
    public partial class frmDanhMucSach : Form
    {
        public frmDanhMucSach()
        {
            InitializeComponent();
        }
        void Trangthainutlenh(string TenNutLenh)
        {
            switch (TenNutLenh)
            {
                case "Thêm":
                    {
                        btn_them.Enabled = false;
                        btn_Xoa.Enabled = false;
                        btn_Sua.Enabled = false;
                        btn_luu.Enabled = true;
                        txt_MaSach.ReadOnly = false;
                        txt_MaSach.Focus();
                        dgv_Danhmucsach.Enabled = false;
                        break;
                    }
                case "Xóa":
                    {
                        btn_them.Enabled = false;
                        btn_Xoa.Enabled = false;
                        btn_Sua.Enabled = false;
                        btn_luu.Enabled = false;
                        txt_MaSach.Focus();

                        break;
                    }
                case "Sửa":
                    {
                        btn_them.Enabled = false;
                        btn_Xoa.Enabled = false;
                        btn_Sua.Enabled = false;
                        btn_luu.Enabled = true;
                        txt_MaSach.ReadOnly = true;
                        txt_TenSach.Focus();
                        dgv_Danhmucsach.Enabled = false;
                        break;
                    }
                case "Lưu":
                    {
                        btn_them.Enabled = true;
                        btn_Xoa.Enabled = false;
                        btn_Sua.Enabled = false;
                        btn_luu.Enabled = false;
                        dgv_Danhmucsach.Enabled = true;
                        break;
                    }
                case "DataGridView":
                    {
                        btn_them.Enabled = true;
                        btn_Xoa.Enabled = true;
                        btn_Sua.Enabled = true;
                        btn_luu.Enabled = false;
                        break;
                    }
                case "Load":
                    {
                        btn_them.Enabled = true;
                        btn_Xoa.Enabled = false;
                        btn_Sua.Enabled = false;
                        btn_luu.Enabled = false;
                        break;
                    }

            }
        }//ket thuc trang thai nut lenh

        Danhmucsanpham danhmucsach;

        private void LoadDataDanhmucsach()
        {
            DataTable tblDanhmucsach;
            danhmucsach = new Danhmucsanpham();
            if (danhmucsach.Connect())
            {
                tblDanhmucsach = danhmucsach.GetDatahDanhMucSach();
                dgv_Danhmucsach.DataSource = tblDanhmucsach;
            }
            else
            {
                MessageBox.Show("Kết nối CSDL thất bại", "Thông Báo!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }

            //Dinh dang datagridview
            dgv_Danhmucsach.Columns["Mahang"].HeaderText = "Mahang";
            dgv_Danhmucsach.Columns["Mahang"].Width = 100;
            dgv_Danhmucsach.Columns["Tenhang"].HeaderText = "Tenhang";
            dgv_Danhmucsach.Columns["Tenhang"].Width = 100;
            dgv_Danhmucsach.Columns["Nhacungcap"].HeaderText = "Nhacungcap";
            dgv_Danhmucsach.Columns["Nhacungcap"].Width = 100;
            dgv_Danhmucsach.Columns["MaNhom"].HeaderText = "MaNhom";
            dgv_Danhmucsach.Columns["MaNhom"].Width = 100;
            dgv_Danhmucsach.Columns["DonGia"].HeaderText = "DonGia";
            dgv_Danhmucsach.Columns["DonGia"].Width = 100;
            dgv_Danhmucsach.Columns["SLTon"].HeaderText = "SLTon";
            dgv_Danhmucsach.Columns["SLTon"].Width = 100;
            BindingDataNhanVien();
        }

        private void BindingDataNhanVien()
        {
            //Xoa cac du lieu tren text box
            txt_MaSach.DataBindings.Clear();
            txt_TenSach.DataBindings.Clear();
            txt_Tacgia.DataBindings.Clear();
            txt_MaNhom.DataBindings.Clear();
            txt_Slton.DataBindings.Clear();
            Txt_Đongia.DataBindings.Clear();

            //databinding du lieu tren textbox
            txt_MaSach.DataBindings.Add("Text", dgv_Danhmucsach.DataSource, "Mahang");
            txt_TenSach.DataBindings.Add("Text", dgv_Danhmucsach.DataSource, "Tenhang");
            txt_Tacgia.DataBindings.Add("Text", dgv_Danhmucsach.DataSource, "Nhacungcap");
            txt_MaNhom.DataBindings.Add("Text", dgv_Danhmucsach.DataSource, "MaNhom");
            Txt_Đongia.DataBindings.Add("Text", dgv_Danhmucsach.DataSource, "DonGia");
            txt_Slton.DataBindings.Add("Text", dgv_Danhmucsach.DataSource, "SLTon");


        }//ket thuc bindingDataNhanVien
        private void frmDanhMucSach_Load(object sender, EventArgs e)
        {
           LoadDataDanhmucsach();
        }
        private void ResertAll()
        {
            txt_MaNhom.Clear();
            txt_MaSach.Clear();
            txt_Slton.Clear();
            txt_Tacgia.Clear();
            txt_TenSach.Clear();
            Txt_Đongia.Clear();
            txt_MaSach.Focus();
        }
        private void btn_them_Click(object sender, EventArgs e)
        {
            ResertAll();
            Trangthainutlenh("Thêm");
        }

        private int deleteDanhmucsach(Danhmucsanpham danhmucsanpham)
        {
            string Sqldeletedanhmucsach = "delete from DanhMucSach Where MaSach=@MaSach";
            string[] parameters = { "@MaSach" };
            object[] values = { txt_MaSach.Text};
            return danhmucsach.DanhmucSachExecuteNonQuery(Sqldeletedanhmucsach, parameters, values, false);
        }

        private void btn_Xoa_Click(object sender, EventArgs e)
        {
            danhmucsach = new Danhmucsanpham();
            if (danhmucsach.Connect())
            {
                DialogResult tb = MessageBox.Show("Ban co chắc muốn xóa dòng dữ liệu này không?", "Thông báo!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (tb == DialogResult.Yes)
                {
                    if (deleteDanhmucsach(danhmucsach) > 0)
                    {
                        MessageBox.Show("Đã Xóa thành công 1 dòng dữ liệu !", "Thông báo!");
                        LoadDataDanhmucsach();
                        Trangthainutlenh("DataGridView");
                    }

                }
                else
                {
                    MessageBox.Show("Ban đã hủy xóa thành công!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Vui lòng kiểm tra lại kết nối CSDL", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Sua_Click(object sender, EventArgs e)
        {
            Trangthainutlenh("Sửa");
        }




        private int InsertDanhmucsach(Danhmucsanpham danhmucsach)
        {
            string SqlInsertdanhmucsach = "Insert into DanhMucSach values (@MaSach,@TenSach,@TacGia,@MaNhom,@DonGia,@SLTon)";
            string[] parameters = { "@MaSach", "@TenSach", "@TacGia", "@MaNhom", "@DonGia", "@SLTon" };
            object[] values = { txt_MaSach.Text, txt_TenSach.Text, txt_Tacgia.Text,txt_MaNhom.Text,Txt_Đongia.Text,txt_Slton.Text };
            return danhmucsach.DanhmucSachExecuteNonQuery(SqlInsertdanhmucsach, parameters, values, false);
        }


        private int UpdateDanhmucsach(Danhmucsanpham danhmucsach)
        {
            string SqlUpdateDanhmucsach = "Update DanhMucSach set TenSach=@TenSach,TacGia=@TacGia,MaNhom=@MaNhom,DonGia=@DonGia,SLTon=@SLTon where MaSach=@MaSach";
            string[] parameters = { "@MaSach", "@TenSach", "@TacGia", "@MaNhom", "@DonGia", "@SLTon" };
            object[] values = { txt_MaSach.Text, txt_TenSach.Text, txt_Tacgia.Text, txt_MaNhom.Text, Txt_Đongia.Text, txt_Slton.Text };
            return danhmucsach.DanhmucSachExecuteNonQuery(SqlUpdateDanhmucsach, parameters, values, false);
        }

        bool SaveFlag = true;
 
        private void btn_luu_Click(object sender, EventArgs e)
        {
            danhmucsach = new Danhmucsanpham();
            if (danhmucsach.Connect())
            {
                if (SaveFlag)
                {
                    if (danhmucsach.CheckManhom(txt_MaNhom.Text) > 0)
                    {
                       if (InsertDanhmucsach(danhmucsach) > 0)
                       {
                            MessageBox.Show("Đã thêm thành công 1 dữ liệu ", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            LoadDataDanhmucsach();
                            Trangthainutlenh("DataGridView");
                        }
                       else
                       {
                            MessageBox.Show("Đã xảy ra lỗi trong quá trình thêm dữ liệu", "Thông bao!");
                       }
                    }
                    else
                        {
                            MessageBox.Show("Vui lòng nhap trùng mã Nhóm trong CSDl ", "Thông bao!");
                        }
                   
                }
                else
                {
                    if (UpdateDanhmucsach(danhmucsach)>0)
                    {
                        MessageBox.Show("Đã cập nhật thành công 1 dữ liệu ", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        LoadDataDanhmucsach();
                        Trangthainutlenh("DataGridView");
                    }
                    else
                    {
                        MessageBox.Show("Đã xảy ra lỗi trong quá trình thêm dữ liệu", "Thông bao!");
                    }
                }
            }
            else
            {
                MessageBox.Show("Kết nối với CSDL thất bại", "Thông bao!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_dong_Click(object sender, EventArgs e)
        {
            DialogResult tb = MessageBox.Show("Ban có muốn thoát form này không?", "Thông Báo!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (tb == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void dgv_Danhmucsach_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            LoadDataDanhmucsach();
        }
    }
}
