﻿namespace Do_an_mo_hinh_3_lop.GUI
{
    partial class frmNhanvien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_MaNV = new System.Windows.Forms.TextBox();
            this.txt_holot = new System.Windows.Forms.TextBox();
            this.txt_TenNV = new System.Windows.Forms.TextBox();
            this.txt_Ngaysinh = new System.Windows.Forms.TextBox();
            this.txt_Phai = new System.Windows.Forms.TextBox();
            this.txt_Diachi = new System.Windows.Forms.TextBox();
            this.dgv_NhanVien = new System.Windows.Forms.DataGridView();
            this.btn_them_Nhanvien = new System.Windows.Forms.Button();
            this.btn_Xoa_NhanVien = new System.Windows.Forms.Button();
            this.btn_Sua_Nhanvien = new System.Windows.Forms.Button();
            this.btn_luu_Nhanvien = new System.Windows.Forms.Button();
            this.btn_dong_nhanvien = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_NhanVien)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(453, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(241, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Thêm Nhân Viên";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(141, 66);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "MaNV :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(141, 127);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 29);
            this.label3.TabIndex = 2;
            this.label3.Text = "Ho Lot :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(141, 186);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 29);
            this.label4.TabIndex = 3;
            this.label4.Text = "Tên NV :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(522, 66);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 29);
            this.label5.TabIndex = 4;
            this.label5.Text = "Phái :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(522, 127);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(146, 29);
            this.label6.TabIndex = 5;
            this.label6.Text = "Ngày Sinh :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(522, 186);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 29);
            this.label7.TabIndex = 6;
            this.label7.Text = "Địa Chỉ :";
            // 
            // txt_MaNV
            // 
            this.txt_MaNV.Location = new System.Drawing.Point(277, 60);
            this.txt_MaNV.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_MaNV.Name = "txt_MaNV";
            this.txt_MaNV.Size = new System.Drawing.Size(115, 35);
            this.txt_MaNV.TabIndex = 1;
            // 
            // txt_holot
            // 
            this.txt_holot.Location = new System.Drawing.Point(277, 122);
            this.txt_holot.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_holot.Name = "txt_holot";
            this.txt_holot.Size = new System.Drawing.Size(163, 35);
            this.txt_holot.TabIndex = 2;
            // 
            // txt_TenNV
            // 
            this.txt_TenNV.Location = new System.Drawing.Point(277, 183);
            this.txt_TenNV.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_TenNV.Name = "txt_TenNV";
            this.txt_TenNV.Size = new System.Drawing.Size(212, 35);
            this.txt_TenNV.TabIndex = 3;
            // 
            // txt_Ngaysinh
            // 
            this.txt_Ngaysinh.Location = new System.Drawing.Point(675, 122);
            this.txt_Ngaysinh.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_Ngaysinh.Name = "txt_Ngaysinh";
            this.txt_Ngaysinh.Size = new System.Drawing.Size(210, 35);
            this.txt_Ngaysinh.TabIndex = 5;
            // 
            // txt_Phai
            // 
            this.txt_Phai.Location = new System.Drawing.Point(675, 60);
            this.txt_Phai.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_Phai.Name = "txt_Phai";
            this.txt_Phai.Size = new System.Drawing.Size(124, 35);
            this.txt_Phai.TabIndex = 4;
            // 
            // txt_Diachi
            // 
            this.txt_Diachi.Location = new System.Drawing.Point(675, 178);
            this.txt_Diachi.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_Diachi.Name = "txt_Diachi";
            this.txt_Diachi.Size = new System.Drawing.Size(337, 35);
            this.txt_Diachi.TabIndex = 6;
            // 
            // dgv_NhanVien
            // 
            this.dgv_NhanVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_NhanVien.Location = new System.Drawing.Point(92, 234);
            this.dgv_NhanVien.Name = "dgv_NhanVien";
            this.dgv_NhanVien.RowTemplate.Height = 28;
            this.dgv_NhanVien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_NhanVien.Size = new System.Drawing.Size(920, 230);
            this.dgv_NhanVien.TabIndex = 15;
            this.dgv_NhanVien.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_NhanVien_CellContentClick);
            // 
            // btn_them_Nhanvien
            // 
            this.btn_them_Nhanvien.Location = new System.Drawing.Point(92, 496);
            this.btn_them_Nhanvien.Name = "btn_them_Nhanvien";
            this.btn_them_Nhanvien.Size = new System.Drawing.Size(169, 48);
            this.btn_them_Nhanvien.TabIndex = 7;
            this.btn_them_Nhanvien.Text = "Thêm";
            this.btn_them_Nhanvien.UseVisualStyleBackColor = true;
            this.btn_them_Nhanvien.Click += new System.EventHandler(this.btn_them_Nhanvien_Click);
            // 
            // btn_Xoa_NhanVien
            // 
            this.btn_Xoa_NhanVien.Location = new System.Drawing.Point(279, 496);
            this.btn_Xoa_NhanVien.Name = "btn_Xoa_NhanVien";
            this.btn_Xoa_NhanVien.Size = new System.Drawing.Size(169, 48);
            this.btn_Xoa_NhanVien.TabIndex = 8;
            this.btn_Xoa_NhanVien.Text = "Xóa";
            this.btn_Xoa_NhanVien.UseVisualStyleBackColor = true;
            this.btn_Xoa_NhanVien.Click += new System.EventHandler(this.btn_Xoa_NhanVien_Click);
            // 
            // btn_Sua_Nhanvien
            // 
            this.btn_Sua_Nhanvien.Location = new System.Drawing.Point(466, 496);
            this.btn_Sua_Nhanvien.Name = "btn_Sua_Nhanvien";
            this.btn_Sua_Nhanvien.Size = new System.Drawing.Size(169, 48);
            this.btn_Sua_Nhanvien.TabIndex = 9;
            this.btn_Sua_Nhanvien.Text = "Sửa";
            this.btn_Sua_Nhanvien.UseVisualStyleBackColor = true;
            this.btn_Sua_Nhanvien.Click += new System.EventHandler(this.btn_Sua_Nhanvien_Click);
            // 
            // btn_luu_Nhanvien
            // 
            this.btn_luu_Nhanvien.Location = new System.Drawing.Point(653, 496);
            this.btn_luu_Nhanvien.Name = "btn_luu_Nhanvien";
            this.btn_luu_Nhanvien.Size = new System.Drawing.Size(169, 48);
            this.btn_luu_Nhanvien.TabIndex = 10;
            this.btn_luu_Nhanvien.Text = "Lưu";
            this.btn_luu_Nhanvien.UseVisualStyleBackColor = true;
            this.btn_luu_Nhanvien.Click += new System.EventHandler(this.btn_luu_Nhanvien_Click);
            // 
            // btn_dong_nhanvien
            // 
            this.btn_dong_nhanvien.Location = new System.Drawing.Point(840, 496);
            this.btn_dong_nhanvien.Name = "btn_dong_nhanvien";
            this.btn_dong_nhanvien.Size = new System.Drawing.Size(169, 48);
            this.btn_dong_nhanvien.TabIndex = 11;
            this.btn_dong_nhanvien.Text = "Đóng";
            this.btn_dong_nhanvien.UseVisualStyleBackColor = true;
            this.btn_dong_nhanvien.Click += new System.EventHandler(this.btn_dong_nhanvien_Click);
            // 
            // frmNhanvien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1085, 577);
            this.Controls.Add(this.btn_dong_nhanvien);
            this.Controls.Add(this.btn_luu_Nhanvien);
            this.Controls.Add(this.btn_Sua_Nhanvien);
            this.Controls.Add(this.btn_Xoa_NhanVien);
            this.Controls.Add(this.btn_them_Nhanvien);
            this.Controls.Add(this.dgv_NhanVien);
            this.Controls.Add(this.txt_Diachi);
            this.Controls.Add(this.txt_Phai);
            this.Controls.Add(this.txt_Ngaysinh);
            this.Controls.Add(this.txt_TenNV);
            this.Controls.Add(this.txt_holot);
            this.Controls.Add(this.txt_MaNV);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Blue;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "frmNhanvien";
            this.Text = "Nhan Vien";
            this.Load += new System.EventHandler(this.frmNhanvien_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_NhanVien)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_MaNV;
        private System.Windows.Forms.TextBox txt_holot;
        private System.Windows.Forms.TextBox txt_TenNV;
        private System.Windows.Forms.TextBox txt_Ngaysinh;
        private System.Windows.Forms.TextBox txt_Phai;
        private System.Windows.Forms.TextBox txt_Diachi;
        private System.Windows.Forms.DataGridView dgv_NhanVien;
        private System.Windows.Forms.Button btn_them_Nhanvien;
        private System.Windows.Forms.Button btn_Xoa_NhanVien;
        private System.Windows.Forms.Button btn_Sua_Nhanvien;
        private System.Windows.Forms.Button btn_luu_Nhanvien;
        private System.Windows.Forms.Button btn_dong_nhanvien;
    }
}