﻿using Do_an_mo_hinh_3_lop.BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Do_an_mo_hinh_3_lop.GUI
{
    public partial class frmHoadon : Form
    {
        public frmHoadon()
        {
            InitializeComponent();
        }
        HoaDon hoadon;
        
        bool SaveFlag = true;

        public DateTime dtl_Ngayban { get; private set; }

        void Trangthainutlenh(string TenNutLenh)
        {
            switch (TenNutLenh)
            {
                case "Thêm":
                    {
                        btn_them_hoadon.Enabled = false;
                        btn_xoa_hoadon.Enabled = false;
                        btn_sua_hoadon.Enabled = false;
                        btn_luu_hoadon.Enabled = true;
                        txt_MaHD.ReadOnly = false;
                        txt_MaHD.Focus();
                        dgv_Hoadon.Enabled = false;
                        break;
                    }
                case "Xóa":
                    {
                        btn_them_hoadon.Enabled = true;
                        btn_xoa_hoadon.Enabled = false;
                        btn_sua_hoadon.Enabled = false;
                        btn_luu_hoadon.Enabled = false;
                        txt_MaHD.Focus();
                        
                        break;
                    }
                case "Sửa":
                    {
                        btn_them_hoadon.Enabled = false;
                        btn_xoa_hoadon.Enabled = false;
                        btn_sua_hoadon.Enabled = false;
                        btn_luu_hoadon.Enabled = true;
                        txt_MaHD.ReadOnly = true;
                        dtp_NgayBan.Focus();
                        dgv_Hoadon.Enabled = false;
                        break;
                    }
                case "Lưu":
                    {
                        btn_them_hoadon.Enabled = true;
                        btn_xoa_hoadon.Enabled = false;
                        btn_sua_hoadon.Enabled = false;
                        btn_luu_hoadon.Enabled = false;
                        btn_them_hoadon.Focus();
                        dgv_Hoadon.Enabled = true;
                        break;
                    }
                case "DataGridView":
                    {
                        btn_them_hoadon.Enabled = true;
                        btn_xoa_hoadon.Enabled = true;
                        btn_sua_hoadon.Enabled = true;
                        btn_luu_hoadon.Enabled = false;
                        break;
                    }
                case "Load":
                    {
                        btn_them_hoadon.Enabled = true;
                        btn_xoa_hoadon.Enabled = false;
                        btn_sua_hoadon.Enabled = false;
                        btn_luu_hoadon.Enabled = false;
                        break;
                    }

            }
        }//ket thuc trang thai nut lenh

        private void LoadDataHoaDon()
        {
            DataTable tblHoadon;
            hoadon = new HoaDon();
            if (hoadon.Connect())
            {
                tblHoadon = hoadon.GetDataHoadon();
                dgv_Hoadon .DataSource = tblHoadon;
            }
            else
            {
                MessageBox.Show("Kết nối CSDL thất bại", "Thông Báo!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }

            //Dinh dang datagridview
            dgv_Hoadon.Columns["MaHD"].HeaderText = "MaHD";
            dgv_Hoadon.Columns["MaHD"].Width = 200;
            dgv_Hoadon.Columns["NgayBan"].HeaderText = "NgayBan";
            dgv_Hoadon.Columns["NgayBan"].Width = 300;
            dgv_Hoadon.Columns["MaNV"].HeaderText = "MaNV";
            dgv_Hoadon.Columns["MaNV"].Width = 200;
            
           
            BindingDataHoaDon();
        }

        private void BindingDataHoaDon()
        {
            //Xoa cac du lieu tren text box
            txt_MaHD.DataBindings.Clear();
            dtp_NgayBan.DataBindings.Clear();
            txt_MaNV.DataBindings.Clear();


            //databinding du lieu tren textbox
            txt_MaHD.DataBindings.Add("Text", dgv_Hoadon.DataSource, "MaHD");
            dtp_NgayBan.DataBindings.Add("value", dgv_Hoadon.DataSource, "NgayBan");
            txt_MaNV.DataBindings.Add("Text", dgv_Hoadon.DataSource, "MaNV");
           


        }//ket thuc bindingDataNhanVien

        private void frmHoadon_Load(object sender, EventArgs e)
        {
            LoadDataHoaDon();
        }

        private void btn_dong_Click(object sender, EventArgs e)
        {
            DialogResult tb = MessageBox.Show("Ban có muốn thoát form này không?", "Thông Báo!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (tb == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void ResertAll()
        {
            txt_MaHD.ReadOnly = false;
            txt_MaHD.Clear();
            txt_MaHD.Focus();
            txt_MaNV.Clear();
        }

        private void btn_them_hoadon_Click(object sender, EventArgs e)
        {
            ResertAll();
            Trangthainutlenh(btn_them_hoadon.Text);
        }


        private int deleteHoadon(HoaDon hoadon)
        {
            string Sqldeletehoadon = "Usp_DeleteHoadon";
            string[] parameters = { "@MaHD"};
            object[] values = { txt_MaHD.Text};
            return hoadon.HoadonExecuteNonQuery(Sqldeletehoadon, parameters, values, true);
        }
        
        private void btn_xoa_hoadon_Click(object sender, EventArgs e)
        {
            hoadon = new HoaDon();
            if (hoadon.Connect())
            {
                DialogResult kq = MessageBox.Show("Ban có chắc muốn xóa dữ liệu này không?", "Thông báo!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (kq == DialogResult.Yes) {
                
                    if (deleteHoadon(hoadon)>0)
                        {
                            MessageBox.Show("Đã xóa 1 dòng thành công ", "Thông bao!");
                            LoadDataHoaDon();
                            Trangthainutlenh("DataGridView");
                    }
                    else
                        {
                        MessageBox.Show("Đã xảy ra lỗi khi xóa dữ liệu", "Thông báo!");
                        }
                }
                else
                {
                    MessageBox.Show("Ban đã hủy thao tác xóa dữ liệu của hóa đơn này !", "Thông bao!");
                }
            }
            else
            {
                MessageBox.Show("Lỗi kết nối CSDL, Vui lòng kiểm tra lại!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        
        }


        private void btn_sua_hoadon_Click(object sender, EventArgs e)
        {
            SaveFlag = false;
            Trangthainutlenh("Sửa");
        }

        private int InsertHoadon(HoaDon hoadon)
        {
            string SqlInsertHoadon = "Insert into HoaDon values(@MaHD,@NgayBan,@MaNV)";
            string[] parameters = {"@MaHD","@NgayBan","@MaNV"};
            object[] values = {txt_MaHD.Text,dtl_Ngayban=Convert.ToDateTime(dtp_NgayBan.Text),txt_MaNV.Text};
            return hoadon.HoadonExecuteNonQuery(SqlInsertHoadon, parameters, values, false);
        }


        private int UpdateHoadon(HoaDon hoadon)
        {
            string SqlUpdateHoadon = "Update HoaDon set NgayBan=@NgayBan,MaNV=@MaNV where MaHD=@MaHD";
            string[] parameters = { "@MaHD","@NgayBan","@MaNV"};
            object[] values = {txt_MaHD.Text, dtl_Ngayban = Convert.ToDateTime(dtp_NgayBan.Text), txt_MaNV.Text};
            return hoadon.HoadonExecuteNonQuery(SqlUpdateHoadon, parameters, values, false);
        }


        private void btn_luu_hoadon_Click(object sender, EventArgs e)
        {
            hoadon = new HoaDon();
            if (hoadon.Connect())
            {
                if (SaveFlag)
                {
                    if (hoadon.CheckHD(txt_MaHD.Text) == 0)
                    {
                        if (hoadon.CheckMaNV(txt_MaNV.Text) > 0)
                        {
                            if (InsertHoadon(hoadon) > 0)
                            {
                                MessageBox.Show("Đã thêm thành công 1 dữ liệu ", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                LoadDataHoaDon();
                                Trangthainutlenh("DataGridView");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Vui lòng chọn Nhân viên có mã trong CSDl ", "Thông bao!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Vui lòng Nhập các MaHD khác với CSDL đã có ", "Thông bao!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                else
                {
                    if (hoadon.CheckMaNV(txt_MaNV.Text) > 0)
                    {
                        if (UpdateHoadon(hoadon) > 0)
                        {
                            MessageBox.Show("Đã cập nhật thành công 1 dữ liệu ", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            LoadDataHoaDon();
                            Trangthainutlenh("DataGridView");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Vui lòng chọn Nhân viên có mã trong CSDl ", "Thông bao!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
            }
            else
            {
                MessageBox.Show("Kết nối với CSDL thất bại", "Thông bao!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgv_Hoadon_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            LoadDataHoaDon();
        }
    }
}
