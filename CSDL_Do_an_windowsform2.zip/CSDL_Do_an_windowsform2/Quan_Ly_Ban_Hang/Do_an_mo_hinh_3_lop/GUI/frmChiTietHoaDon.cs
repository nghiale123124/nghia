﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Do_an_mo_hinh_3_lop.BLL;


namespace Do_an_mo_hinh_3_lop.GUI
{
    public partial class frmChiTietHoaDon : Form
    {
        public frmChiTietHoaDon()
        {
            InitializeComponent();
        }

       

        Chitiethoadon chitiethoadon;

        private void LoadDataChiTietHoaDon()
        {
            DataTable tblHoadon;
            chitiethoadon = new Chitiethoadon();
            if (chitiethoadon.Connect())
            {
                tblHoadon = chitiethoadon.GetDataChitiethoadon();
                dgv_Bangchitiethoadon.DataSource = tblHoadon;
            }
            else
            {
                MessageBox.Show("Kết nối CSDL thất bại", "Thông Báo!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }

            //Dinh dang datagridview
            dgv_Bangchitiethoadon.Columns["MaHD"].HeaderText = "MaHD";
            dgv_Bangchitiethoadon.Columns["MaHD"].Width = 200;
            dgv_Bangchitiethoadon.Columns["Mahang"].HeaderText = "Mahang";
            dgv_Bangchitiethoadon.Columns["Mahang"].Width = 300;
            dgv_Bangchitiethoadon.Columns["SoLuong"].HeaderText = "SoLuong";
            dgv_Bangchitiethoadon.Columns["SoLuong"].Width = 200;


            BindingDataHoaDon();
        }

        private void BindingDataHoaDon()
        {
            //Xoa cac du lieu tren text box
            txt_MaHD.DataBindings.Clear();
            txt_Masach.DataBindings.Clear();
            txt_Soluong.DataBindings.Clear();

            //databinding du lieu tren textbox
            txt_MaHD.DataBindings.Add("Text", dgv_Bangchitiethoadon.DataSource, "MaHD");
            txt_Masach.DataBindings.Add("Text", dgv_Bangchitiethoadon.DataSource, "Mahang");
            txt_Soluong.DataBindings.Add("Text", dgv_Bangchitiethoadon.DataSource, "SoLuong");

        }//ket thuc bindingDataNhanVien

        private void frmChiTietHoaDon_Load(object sender, EventArgs e)
        {
            LoadDataChiTietHoaDon();
        }


        private void btn_dong_Chitiethoadon_Click(object sender, EventArgs e)
        {
            DialogResult tb = MessageBox.Show("Ban có muốn thoát form này không?", "Thông Báo!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (tb == DialogResult.Yes)
            {
                this.Close();
            }
        }
        void Trangthainutlenh(string TenNutLenh)
        {
            switch (TenNutLenh)
            {
                case "Thêm":
                    {
                        btn_them_ChiTiethoadon.Enabled = false;
                        btn_Xoa_Chitiethoadon.Enabled = false;
                        btn_Sua_Chitiethoadon.Enabled = false;
                        btn_luu_Chitiethoadon.Enabled = true;
                        txt_MaHD.ReadOnly = false;
                        txt_MaHD.Focus();
                        dgv_Bangchitiethoadon.Enabled = false;
                        break;
                    }
                case "Xóa":
                    {
                        btn_them_ChiTiethoadon.Enabled = true;
                        btn_Xoa_Chitiethoadon.Enabled = false;
                        btn_Sua_Chitiethoadon.Enabled = false;
                        btn_luu_Chitiethoadon.Enabled = false;
                        txt_MaHD.Focus();

                        break;
                    }
                case "Sửa":
                    {
                        btn_them_ChiTiethoadon.Enabled = false;
                        btn_Xoa_Chitiethoadon.Enabled = false;
                        btn_Sua_Chitiethoadon.Enabled = false;
                        btn_luu_Chitiethoadon.Enabled = true;
                        txt_MaHD.ReadOnly = true;
                        txt_Masach.ReadOnly = true;
                        txt_Soluong.Focus();
                        dgv_Bangchitiethoadon.Enabled = true;
                        break;
                    }
                case "Lưu":
                    {
                        btn_them_ChiTiethoadon.Enabled = true;
                        btn_Xoa_Chitiethoadon.Enabled = false;
                        btn_Sua_Chitiethoadon.Enabled = false;
                        btn_luu_Chitiethoadon.Enabled = false;   
                        dgv_Bangchitiethoadon.Enabled = true;
                        break;
                    }
                case "DataGridView":
                    {
                        btn_them_ChiTiethoadon.Enabled = true;
                        btn_Xoa_Chitiethoadon.Enabled = true;
                        btn_Sua_Chitiethoadon.Enabled = true;
                        btn_luu_Chitiethoadon.Enabled = false;
                        break;
                    }
                case "Load":
                    {
                        btn_them_ChiTiethoadon.Enabled = true;
                        btn_Xoa_Chitiethoadon.Enabled = false;
                        btn_Sua_Chitiethoadon.Enabled = false;
                        btn_luu_Chitiethoadon.Enabled = false;
                        break;
                    }

            }
        }//ket thuc trang thai nut lenh

        private void ResertAll()
        {
            txt_MaHD.Clear();
            txt_MaHD.Focus();
            txt_Masach.Clear();
            txt_Soluong.Clear();
        }


        private void btn_them_ChiTiethoadon_Click(object sender, EventArgs e)
        {
            ResertAll();
            Trangthainutlenh("Thêm");
        }



        private int deleteChiTietHoadon(Chitiethoadon chitiethoadon)
        {
            string Sqldeletechitiethoadon = "delete from ChiTietHoaDon Where MaHD=@MaHD and MaSach=@MaSach and SoLuong=@SoLuong";
            string[] parameters = { "@MaHD","@MaSach","@SoLuong"};
            object[] values = { txt_MaHD.Text,txt_Masach.Text,txt_Soluong.Text};
            return chitiethoadon.ChiTietHoadonExecuteNonQuery(Sqldeletechitiethoadon, parameters, values, false);
        }

        private void btn_Xoa_Chitiethoadon_Click(object sender, EventArgs e)
        {
            chitiethoadon = new Chitiethoadon();
            if (chitiethoadon.Connect())
            {
                DialogResult tb = MessageBox.Show("Ban co chắc muốn xóa dòng dữ liệu này không?", "Thông báo!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (tb == DialogResult.Yes)
                {
                    if (deleteChiTietHoadon(chitiethoadon) > 0)
                    {
                        MessageBox.Show("Đã Xóa thành công 1 dòng dữ liệu !", "Thông báo!");
                        LoadDataChiTietHoaDon();
                        Trangthainutlenh("DataGridView");
                    }

                }
                else
                {
                    MessageBox.Show("Ban đã hủy xóa thành công!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Vui lòng kiểm tra lại kết nối CSDL", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Sua_Chitiethoadon_Click(object sender, EventArgs e)
        {
            Trangthainutlenh("Sửa");
        }




        private int InsertChiTietHoadon(Chitiethoadon chitiethoadon)
        {
            string SqlInsertHoadon = "Insert into ChiTietHoaDon(MaHD,MaSach,SoLuong) values (@MaHD,@MaSach,@SoLuong)";
            string[] parameters = { "@MaHD", "@MaSach", "@SoLuong" };
            object[] values = { txt_MaHD.Text,txt_Masach.Text, txt_Soluong.Text };
            return chitiethoadon.ChiTietHoadonExecuteNonQuery(SqlInsertHoadon, parameters, values, false);
        }


        private int UpdatechitietHoadon(Chitiethoadon chitiethoadon)
        {
            string SqlUpdateChiTietHoadon = "Update ChiTietHoaDon set MaSach=@MaSach,SoLuong=@SoLuong where MaHD=@MaHD";
            string[] parameters = { "@MaHD","@MaSach","@SoLuong"};
            object[] values = { txt_MaHD.Text,txt_Masach.Text,txt_Soluong.Text };
            return chitiethoadon.ChiTietHoadonExecuteNonQuery(SqlUpdateChiTietHoadon, parameters, values, false);
        }

        bool SaveFlag = true;

        private void btn_luu_Chitiethoadon_Click(object sender, EventArgs e)
        {
            chitiethoadon = new Chitiethoadon();
            if (chitiethoadon.Connect())
            {
                if (SaveFlag)
                {
                    if (chitiethoadon.CheckMaHD(txt_MaHD.Text) > 0)
                    {
                        if (chitiethoadon.CheckMaSach(txt_Masach.Text) >  0)
                        {
                            if (InsertChiTietHoadon(chitiethoadon) > 0)
                            {
                                MessageBox.Show("Đã thêm thành công 1 dữ liệu ", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                LoadDataChiTietHoaDon();
                                Trangthainutlenh("DataGridView");
                            }
                        }
                        else
                        {
                             MessageBox.Show("Vui lòng nhap trùng mã sách trong CSDl ", "Thông bao!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Vui lòng nhap trùng Mã Hóa Đơn trong CSDl ", "Thông bao!");
                    }
                }
                else
                {
                    if (UpdatechitietHoadon(chitiethoadon) > 0)
                    {
                        MessageBox.Show("Đã thêm thành công 1 dữ liệu ", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        LoadDataChiTietHoaDon();
                        Trangthainutlenh("DataGridView");
                    } 
                }
            }
            else
            {
                MessageBox.Show("Kết nối với CSDL thất bại", "Thông bao!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgv_Bangchitiethoadon_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            LoadDataChiTietHoaDon();
        }
    }
}
