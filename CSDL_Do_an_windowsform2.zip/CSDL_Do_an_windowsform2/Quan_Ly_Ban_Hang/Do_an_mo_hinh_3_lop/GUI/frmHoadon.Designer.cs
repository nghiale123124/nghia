﻿namespace Do_an_mo_hinh_3_lop.GUI
{
    partial class frmHoadon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_MaHD = new System.Windows.Forms.TextBox();
            this.txt_MaNV = new System.Windows.Forms.TextBox();
            this.dgv_Hoadon = new System.Windows.Forms.DataGridView();
            this.btn_them_hoadon = new System.Windows.Forms.Button();
            this.btn_sua_hoadon = new System.Windows.Forms.Button();
            this.btn_xoa_hoadon = new System.Windows.Forms.Button();
            this.btn_luu_hoadon = new System.Windows.Forms.Button();
            this.btn_dong_hoadon = new System.Windows.Forms.Button();
            this.dtp_NgayBan = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Hoadon)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(356, 19);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hóa Đơn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(87, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "MaHD";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(87, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Ngày Bán";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(87, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "MaNV";
            // 
            // txt_MaHD
            // 
            this.txt_MaHD.Location = new System.Drawing.Point(200, 73);
            this.txt_MaHD.Name = "txt_MaHD";
            this.txt_MaHD.Size = new System.Drawing.Size(142, 30);
            this.txt_MaHD.TabIndex = 4;
            // 
            // txt_MaNV
            // 
            this.txt_MaNV.Location = new System.Drawing.Point(200, 171);
            this.txt_MaNV.Name = "txt_MaNV";
            this.txt_MaNV.Size = new System.Drawing.Size(142, 30);
            this.txt_MaNV.TabIndex = 6;
            // 
            // dgv_Hoadon
            // 
            this.dgv_Hoadon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Hoadon.Location = new System.Drawing.Point(92, 230);
            this.dgv_Hoadon.Name = "dgv_Hoadon";
            this.dgv_Hoadon.RowTemplate.Height = 28;
            this.dgv_Hoadon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Hoadon.Size = new System.Drawing.Size(667, 146);
            this.dgv_Hoadon.TabIndex = 7;
            this.dgv_Hoadon.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Hoadon_CellContentClick);
            // 
            // btn_them_hoadon
            // 
            this.btn_them_hoadon.Location = new System.Drawing.Point(92, 416);
            this.btn_them_hoadon.Name = "btn_them_hoadon";
            this.btn_them_hoadon.Size = new System.Drawing.Size(112, 47);
            this.btn_them_hoadon.TabIndex = 8;
            this.btn_them_hoadon.Text = "Thêm";
            this.btn_them_hoadon.UseVisualStyleBackColor = true;
            this.btn_them_hoadon.Click += new System.EventHandler(this.btn_them_hoadon_Click);
            // 
            // btn_sua_hoadon
            // 
            this.btn_sua_hoadon.Location = new System.Drawing.Point(230, 416);
            this.btn_sua_hoadon.Name = "btn_sua_hoadon";
            this.btn_sua_hoadon.Size = new System.Drawing.Size(112, 47);
            this.btn_sua_hoadon.TabIndex = 9;
            this.btn_sua_hoadon.Text = "Sửa";
            this.btn_sua_hoadon.UseVisualStyleBackColor = true;
            this.btn_sua_hoadon.Click += new System.EventHandler(this.btn_sua_hoadon_Click);
            // 
            // btn_xoa_hoadon
            // 
            this.btn_xoa_hoadon.Location = new System.Drawing.Point(368, 416);
            this.btn_xoa_hoadon.Name = "btn_xoa_hoadon";
            this.btn_xoa_hoadon.Size = new System.Drawing.Size(112, 47);
            this.btn_xoa_hoadon.TabIndex = 10;
            this.btn_xoa_hoadon.Text = "Xóa";
            this.btn_xoa_hoadon.UseVisualStyleBackColor = true;
            this.btn_xoa_hoadon.Click += new System.EventHandler(this.btn_xoa_hoadon_Click);
            // 
            // btn_luu_hoadon
            // 
            this.btn_luu_hoadon.Location = new System.Drawing.Point(506, 416);
            this.btn_luu_hoadon.Name = "btn_luu_hoadon";
            this.btn_luu_hoadon.Size = new System.Drawing.Size(112, 47);
            this.btn_luu_hoadon.TabIndex = 11;
            this.btn_luu_hoadon.Text = "Lưu";
            this.btn_luu_hoadon.UseVisualStyleBackColor = true;
            this.btn_luu_hoadon.Click += new System.EventHandler(this.btn_luu_hoadon_Click);
            // 
            // btn_dong_hoadon
            // 
            this.btn_dong_hoadon.Location = new System.Drawing.Point(644, 416);
            this.btn_dong_hoadon.Name = "btn_dong_hoadon";
            this.btn_dong_hoadon.Size = new System.Drawing.Size(112, 47);
            this.btn_dong_hoadon.TabIndex = 12;
            this.btn_dong_hoadon.Text = "Đóng";
            this.btn_dong_hoadon.UseVisualStyleBackColor = true;
            this.btn_dong_hoadon.Click += new System.EventHandler(this.btn_dong_Click);
            // 
            // dtp_NgayBan
            // 
            this.dtp_NgayBan.Location = new System.Drawing.Point(200, 125);
            this.dtp_NgayBan.Name = "dtp_NgayBan";
            this.dtp_NgayBan.Size = new System.Drawing.Size(311, 30);
            this.dtp_NgayBan.TabIndex = 13;
            // 
            // frmHoadon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(844, 503);
            this.Controls.Add(this.dtp_NgayBan);
            this.Controls.Add(this.btn_dong_hoadon);
            this.Controls.Add(this.btn_luu_hoadon);
            this.Controls.Add(this.btn_xoa_hoadon);
            this.Controls.Add(this.btn_sua_hoadon);
            this.Controls.Add(this.btn_them_hoadon);
            this.Controls.Add(this.dgv_Hoadon);
            this.Controls.Add(this.txt_MaNV);
            this.Controls.Add(this.txt_MaHD);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Blue;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmHoadon";
            this.Text = "Hóa Đơn";
            this.Load += new System.EventHandler(this.frmHoadon_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Hoadon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_MaHD;
        private System.Windows.Forms.TextBox txt_MaNV;
        private System.Windows.Forms.DataGridView dgv_Hoadon;
        private System.Windows.Forms.Button btn_them_hoadon;
        private System.Windows.Forms.Button btn_sua_hoadon;
        private System.Windows.Forms.Button btn_xoa_hoadon;
        private System.Windows.Forms.Button btn_luu_hoadon;
        private System.Windows.Forms.Button btn_dong_hoadon;
        private System.Windows.Forms.DateTimePicker dtp_NgayBan;
    }
}