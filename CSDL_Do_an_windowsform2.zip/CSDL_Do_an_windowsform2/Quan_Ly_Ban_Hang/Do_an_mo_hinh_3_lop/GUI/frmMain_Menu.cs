﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Do_an_mo_hinh_3_lop.GUI
{
    public partial class frmMain_Menu : Form
    {
        public frmMain_Menu()
        {
            InitializeComponent();
        }
        private string User_name;

        public frmMain_Menu(string txt_User_name)
        {
            InitializeComponent();
            this.User_name = txt_User_name;
        }
       


        private void hethong_thoat_Click(object sender, EventArgs e)
        {
            DialogResult thoat = MessageBox.Show("Ban có muốn thoát Main_Menu này hay không?", "Thông báo !", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (thoat == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void Quanlynhanvien_Nhanvien_Thêmnhavien_Click(object sender, EventArgs e)
        {
            frmNhanvien frm = new frmNhanvien();
            frm.ShowDialog();
        }

        private void Quanlynhanvien_Nhanvien_Timnhanvien_Click(object sender, EventArgs e)
        {
            frmTimnhanvien frm = new frmTimnhanvien();
            frm.ShowDialog();
        }

        private void Quanlyhoadon_Hoadon_Click(object sender, EventArgs e)
        {
            frmHoadon frm = new frmHoadon();
            frm.ShowDialog();
        }

        private void Quanlyhoadon_chitiethoadon_Click(object sender, EventArgs e)
        {
            frmChiTietHoaDon frm = new frmChiTietHoaDon();
            frm.ShowDialog();
        }

        private void Quanlysach_Nhomsach_Click(object sender, EventArgs e)
        {
            frmNhomhang frm = new frmNhomhang();
            frm.ShowDialog();
        }

        private void Quanlysach_Danhmucsach_Click(object sender, EventArgs e)
        {
            frmDanhMucSach frm = new frmDanhMucSach();
            frm.ShowDialog();
        }

        private void menu_Help_Click(object sender, EventArgs e)
        {
           /* frmHelp frm = new frmHelp();
            frm.ShowDialog();*/
        }

        private void frmMain_Menu_Load(object sender, EventArgs e)
        {
           /* lblusername.Text = User_name;
            DateTime thoigian = DateTime.Now;
            lblthoigian.Text = thoigian.ToString();*/
        }

        private void hethong_Quanlynguoidung_Click(object sender, EventArgs e)
        {

        }

        private void menu_Quanlysach_Click(object sender, EventArgs e)
        {

        }
    }
}
