﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Do_an_mo_hinh_3_lop.BLL;

namespace Do_an_mo_hinh_3_lop.GUI
{
    public partial class frmNhanvien : Form
    {
        bool SaveFlag = true;

        //khai bao bien toan cuc
        nhanvien nhanvien;
        //bool SaveFlag = true;

        public frmNhanvien()
        {
            InitializeComponent();
        }


        private void frmNhanvien_Load(object sender, EventArgs e)
        {
            LoadDataNhanVien();
        }

        void Trangthainutlenh(string TenNutLenh)
        {
            switch (TenNutLenh)
            {
                case "Thêm":
                    {
                        btn_them_Nhanvien.Enabled = false;
                        btn_Xoa_NhanVien.Enabled = false;
                        btn_Sua_Nhanvien.Enabled = false;
                        btn_luu_Nhanvien.Enabled = true;
                        txt_MaNV.ReadOnly = false;
                        txt_MaNV.Focus();
                        dgv_NhanVien.Enabled = false;
                        break;
                    }
                case "Xóa":
                    {
                        btn_them_Nhanvien.Enabled = true;
                        btn_Xoa_NhanVien.Enabled = false;
                        btn_Sua_Nhanvien.Enabled = false;
                        btn_luu_Nhanvien.Enabled = false;
                        txt_holot.Focus();

                        break;
                    }
                case "Sửa":
                    {
                        btn_them_Nhanvien.Enabled = false;
                        btn_Xoa_NhanVien.Enabled = false;
                        btn_Sua_Nhanvien.Enabled = false;
                        btn_luu_Nhanvien.Enabled = true;
                        txt_MaNV.ReadOnly = true;
                        txt_holot.Focus();
                        dgv_NhanVien.Enabled = false;
                        break;
                    }
                case "Lưu":
                    {
                        btn_them_Nhanvien.Enabled = true;
                        btn_Xoa_NhanVien.Enabled = false;
                        btn_Sua_Nhanvien.Enabled = false;
                        btn_luu_Nhanvien.Enabled = false;
                        btn_them_Nhanvien.Focus();
                        dgv_NhanVien.Enabled = true;
                        break;
                    }
                case "DataGridView":
                    {
                        btn_them_Nhanvien.Enabled = true;
                        btn_Xoa_NhanVien.Enabled = true;
                        btn_Sua_Nhanvien.Enabled = true;
                        btn_luu_Nhanvien.Enabled = false;
                        break;
                    }
                case "Load":
                    {
                        btn_them_Nhanvien.Enabled = true;
                        btn_Xoa_NhanVien.Enabled = false;
                        btn_Sua_Nhanvien.Enabled = false;
                        btn_luu_Nhanvien.Enabled = false;
                        break;
                    }

            }
        }//ket thuc trang thai nut lenh

        private void LoadDataNhanVien()
        {
            DataTable tblNhanVien;
            nhanvien = new nhanvien();
            if (nhanvien.Connect())
            {
                tblNhanVien = nhanvien.GetDataNhanVien();
                dgv_NhanVien.DataSource = tblNhanVien;
            }
            else
            {
                MessageBox.Show("Kết nối CSDL thất bại", "Thông Báo!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }

            //Dinh dang datagridview
            dgv_NhanVien.Columns["MaNV"].HeaderText = "MaNV";
            dgv_NhanVien.Columns["MaNV"].Width = 100;
            dgv_NhanVien.Columns["HoLot"].HeaderText = "HoLot";
            dgv_NhanVien.Columns["HoLot"].Width = 200;
            dgv_NhanVien.Columns["TenNV"].HeaderText = "TenNV";
            dgv_NhanVien.Columns["TenNV"].Width = 150;
            dgv_NhanVien.Columns["Phai"].HeaderText = "Phai";
            dgv_NhanVien.Columns["Phai"].Width = 100;
            dgv_NhanVien.Columns["NgaySinh"].HeaderText = "NgaySinh";
            dgv_NhanVien.Columns["NgaySinh"].Width = 100;
            dgv_NhanVien.Columns["DiaChi"].HeaderText = "DiaChi";
            dgv_NhanVien.Columns["DiaChi"].Width = 250;
            BindingDataNhanVien();
        }

        private void BindingDataNhanVien()
        {
            //Xoa cac du lieu tren text box
            txt_MaNV.DataBindings.Clear();
            txt_holot.DataBindings.Clear();
            txt_TenNV.DataBindings.Clear();
            txt_Phai.DataBindings.Clear();
            txt_Ngaysinh.DataBindings.Clear();
            txt_Diachi.DataBindings.Clear();

            //databinding du lieu tren textbox
            txt_MaNV.DataBindings.Add("Text", dgv_NhanVien.DataSource,"MaNV");
            txt_holot.DataBindings.Add("Text", dgv_NhanVien.DataSource,"HoLot");
            txt_TenNV.DataBindings.Add("Text", dgv_NhanVien.DataSource,"TenNV");
            txt_Phai.DataBindings.Add("Text", dgv_NhanVien.DataSource,"Phai");
            txt_Ngaysinh.DataBindings.Add("Text", dgv_NhanVien.DataSource,"NgaySinh");
            txt_Diachi.DataBindings.Add("Text", dgv_NhanVien.DataSource, "Diachi");

            
        }//ket thuc bindingDataNhanVien


        private void btn_dong_nhanvien_Click(object sender, EventArgs e)
        {
            DialogResult thoat = MessageBox.Show("Ban có muốn đóng cửa sổ Nhân Viên này hay không?", "Thông báo !", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (thoat == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void ResetAll()
        {
            txt_MaNV.ResetText();
            txt_holot.Clear();
            txt_TenNV.Clear();
            txt_Phai.Clear();
            txt_Ngaysinh.Clear();
            txt_Diachi.Clear();
        }//ket thuc resetAll

        private void btn_them_Nhanvien_Click(object sender, EventArgs e)
        {

            ResetAll();
            Trangthainutlenh("Thêm");
        }//ket thuc btn them


        private int DeleteNhanVien(nhanvien nhanvien)
        {
            string SqlDeleteNhanvien = "delete from NhanVien Where MaNV=@MaNV";
            string[] parameters = { "@MaNV" };
            object[] values = { txt_MaNV.Text};
            return nhanvien.NhanVienExecuteNonQuery(SqlDeleteNhanvien, parameters,values,false);
        }//ket thuc ham deleteNhanVien

       
        private int UpdateNhanVien(nhanvien  nhanvien)
        { 
           // string SqlUpdateNhanvien = "Usp_UpdateNhanvien"; cau lenh proc
            string SqlUpdateNhanvien= "update NhanVien set MaNV=@MaNV,HoLot=@HoLot,TenNV=@TenNV,Phai=@Phai,NgaySinh=@NgaySinh,DiaChi=@DiaChi where MaNV=@MaNV";
            string[] parameters = { "@MaNV", "@HoLot", "@TenNV", "@Phai", "@NgaySinh", "@Diachi"};
            object[] values = { txt_MaNV.Text,txt_holot.Text, txt_TenNV.Text, txt_Phai.Text, dtl_ngaysinh = Convert.ToDateTime(txt_Ngaysinh.Text), txt_Diachi.Text };
            return nhanvien.NhanVienExecuteNonQuery(SqlUpdateNhanvien, parameters, values, false);
        }

       
        private void btn_Xoa_NhanVien_Click(object sender, EventArgs e)
        {
            nhanvien = new nhanvien();
            if (nhanvien.Connect())
            {
                DialogResult kq = MessageBox.Show("Bạn có muốn xóa dòng dữ liệu này không?", "Thông bao!", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
                if (kq == DialogResult.Yes)
                {
                    if (nhanvien.CheckMaNVTrongHD(txt_MaNV.Text) == 0)
                    {
                        if (DeleteNhanVien(nhanvien) > 0)
                        {
                            MessageBox.Show("Đã xóa thành công 1 dòng", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            LoadDataNhanVien();
                            Trangthainutlenh("DataGridView");
                        }
                        else
                        {
                            LoadDataNhanVien();
                            MessageBox.Show("Đã xảy ra lỗi khi xóa dữ liệu, xin kiểm tra lại", "Thông bao!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Bạn phải xóa các hợp đồng có MaNV này sử dụng !!!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Bạn đã hủy bỏ xóa hàng này!", "Thông bao!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
            else
            {
                MessageBox.Show("kết nối với CSDl thât bại, vui lòng kiểm tra lại","Thông bao!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private DateTime dtl_ngaysinh;


        private int InsertNhanvien(nhanvien nhanvien)
        {
            //string SqlinsertNhanVien = "Usp_InsertNhanVien";
            string SqlinsertNhanVien= "insert into NhanVien value(MaNV=@MaNV,HoLot=@HoLot,TenNV=@TenNV,Phai=@Phai,NgaySinh=@NgaySinh,DiaChi=@DiaChi)";
            string[] parameters = { "@MaNV", "@HoLot", "@TenNV", "@Phai", "@NgaySinh", "@Diachi" };
            object[] values = { txt_MaNV.Text, txt_holot.Text, txt_TenNV.Text, txt_Phai.Text, dtl_ngaysinh=Convert.ToDateTime(txt_Ngaysinh.Text), txt_Diachi.Text };
            return nhanvien.NhanVienExecuteNonQuery(SqlinsertNhanVien, parameters, values, false);
        }



        private void btn_luu_Nhanvien_Click(object sender, EventArgs e)
        {
            nhanvien = new nhanvien ();
            if (nhanvien.Connect())
            {
                if (SaveFlag)
                {
                    if (nhanvien.CheckMaNV(txt_MaNV.Text)==0)
                    {
                        if (InsertNhanvien(nhanvien) > 0)
                        {
                            MessageBox.Show("Đã thêm thành công ", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            LoadDataNhanVien();
                            Trangthainutlenh("DataGridView");
                        }
                        else
                        {
                            MessageBox.Show("Đã xảy ra lỗi khi thêm dữ liệu", "Thông báo");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Mã Nhân Viên này đã tồn tại trong hệ thống CSDL !!!", "Thông bao!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    
                }
                else
                {
                    if (UpdateNhanVien(nhanvien) > 0)
                    {
                        MessageBox.Show("Đã cập nhật dữ liệu thành công","Thông bao!");
                        LoadDataNhanVien();
                        Trangthainutlenh("DataGridView");
                    }
                    else
                    {
                        MessageBox.Show("Đã xảy ra lỗi khi cập nhật dữ liệu ?", "Thông báo!");
                    }
                }

            }
            else
            {
                MessageBox.Show("Vui lòng kiểm tra kết nối CSDL", "Thông bao!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Sua_Nhanvien_Click(object sender, EventArgs e)
        {
            txt_MaNV.ReadOnly = true;
            SaveFlag = false;
            Trangthainutlenh("Sửa");
        }

        private void dgv_NhanVien_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            LoadDataNhanVien();
           
        }
    }
}
