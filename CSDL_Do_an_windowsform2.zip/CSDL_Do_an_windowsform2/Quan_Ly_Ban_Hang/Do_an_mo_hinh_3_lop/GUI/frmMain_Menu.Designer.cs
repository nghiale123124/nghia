﻿namespace Do_an_mo_hinh_3_lop.GUI
{
    partial class frmMain_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain_Menu));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menu_Quanlynhanvien = new System.Windows.Forms.ToolStripMenuItem();
            this.Quanlynhanvien_Nhanvien = new System.Windows.Forms.ToolStripMenuItem();
            this.Quanlynhanvien_Nhanvien_Thêmnhavien = new System.Windows.Forms.ToolStripMenuItem();
            this.Quanlynhanvien_Nhanvien_Timnhanvien = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_Quanlyhoadon = new System.Windows.Forms.ToolStripMenuItem();
            this.Quanlyhoadon_Hoadon = new System.Windows.Forms.ToolStripMenuItem();
            this.Quanlyhoadon_chitiethoadon = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_Quanlysach = new System.Windows.Forms.ToolStripMenuItem();
            this.Quanlysach_Nhomsach = new System.Windows.Forms.ToolStripMenuItem();
            this.Quanlysach_Danhmucsach = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_Quanlynhanvien,
            this.menu_Quanlyhoadon,
            this.menu_Quanlysach});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 1, 0, 1);
            this.menuStrip1.Size = new System.Drawing.Size(762, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menu_Quanlynhanvien
            // 
            this.menu_Quanlynhanvien.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Quanlynhanvien_Nhanvien});
            this.menu_Quanlynhanvien.Name = "menu_Quanlynhanvien";
            this.menu_Quanlynhanvien.Size = new System.Drawing.Size(120, 22);
            this.menu_Quanlynhanvien.Text = "Quản Lý Nhân Viên";
            // 
            // Quanlynhanvien_Nhanvien
            // 
            this.Quanlynhanvien_Nhanvien.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Quanlynhanvien_Nhanvien_Thêmnhavien,
            this.Quanlynhanvien_Nhanvien_Timnhanvien});
            this.Quanlynhanvien_Nhanvien.Name = "Quanlynhanvien_Nhanvien";
            this.Quanlynhanvien_Nhanvien.Size = new System.Drawing.Size(180, 22);
            this.Quanlynhanvien_Nhanvien.Text = "Nhân Viên";
            // 
            // Quanlynhanvien_Nhanvien_Thêmnhavien
            // 
            this.Quanlynhanvien_Nhanvien_Thêmnhavien.Name = "Quanlynhanvien_Nhanvien_Thêmnhavien";
            this.Quanlynhanvien_Nhanvien_Thêmnhavien.Size = new System.Drawing.Size(185, 22);
            this.Quanlynhanvien_Nhanvien_Thêmnhavien.Text = "Thông Tin Nhân Viên";
            this.Quanlynhanvien_Nhanvien_Thêmnhavien.Click += new System.EventHandler(this.Quanlynhanvien_Nhanvien_Thêmnhavien_Click);
            // 
            // Quanlynhanvien_Nhanvien_Timnhanvien
            // 
            this.Quanlynhanvien_Nhanvien_Timnhanvien.Name = "Quanlynhanvien_Nhanvien_Timnhanvien";
            this.Quanlynhanvien_Nhanvien_Timnhanvien.Size = new System.Drawing.Size(185, 22);
            this.Quanlynhanvien_Nhanvien_Timnhanvien.Text = "Tìm Nhân Viên";
            this.Quanlynhanvien_Nhanvien_Timnhanvien.Click += new System.EventHandler(this.Quanlynhanvien_Nhanvien_Timnhanvien_Click);
            // 
            // menu_Quanlyhoadon
            // 
            this.menu_Quanlyhoadon.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Quanlyhoadon_Hoadon,
            this.Quanlyhoadon_chitiethoadon});
            this.menu_Quanlyhoadon.Name = "menu_Quanlyhoadon";
            this.menu_Quanlyhoadon.Size = new System.Drawing.Size(112, 22);
            this.menu_Quanlyhoadon.Text = "Quản Lý Hóa Đơn";
            // 
            // Quanlyhoadon_Hoadon
            // 
            this.Quanlyhoadon_Hoadon.Name = "Quanlyhoadon_Hoadon";
            this.Quanlyhoadon_Hoadon.Size = new System.Drawing.Size(164, 22);
            this.Quanlyhoadon_Hoadon.Text = "Hóa Đơn";
            this.Quanlyhoadon_Hoadon.Click += new System.EventHandler(this.Quanlyhoadon_Hoadon_Click);
            // 
            // Quanlyhoadon_chitiethoadon
            // 
            this.Quanlyhoadon_chitiethoadon.Name = "Quanlyhoadon_chitiethoadon";
            this.Quanlyhoadon_chitiethoadon.Size = new System.Drawing.Size(164, 22);
            this.Quanlyhoadon_chitiethoadon.Text = "Chi Tiết Hóa Đơn";
            this.Quanlyhoadon_chitiethoadon.Click += new System.EventHandler(this.Quanlyhoadon_chitiethoadon_Click);
            // 
            // menu_Quanlysach
            // 
            this.menu_Quanlysach.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Quanlysach_Nhomsach,
            this.Quanlysach_Danhmucsach});
            this.menu_Quanlysach.Name = "menu_Quanlysach";
            this.menu_Quanlysach.Size = new System.Drawing.Size(174, 22);
            this.menu_Quanlysach.Text = "Quản lý Danh Mục Sản Phẩm";
            this.menu_Quanlysach.Click += new System.EventHandler(this.menu_Quanlysach_Click);
            // 
            // Quanlysach_Nhomsach
            // 
            this.Quanlysach_Nhomsach.Name = "Quanlysach_Nhomsach";
            this.Quanlysach_Nhomsach.Size = new System.Drawing.Size(186, 22);
            this.Quanlysach_Nhomsach.Text = "Nhóm Hàng";
            this.Quanlysach_Nhomsach.Click += new System.EventHandler(this.Quanlysach_Nhomsach_Click);
            // 
            // Quanlysach_Danhmucsach
            // 
            this.Quanlysach_Danhmucsach.Name = "Quanlysach_Danhmucsach";
            this.Quanlysach_Danhmucsach.Size = new System.Drawing.Size(186, 22);
            this.Quanlysach_Danhmucsach.Text = "Danh Mục Hàng Hóa";
            this.Quanlysach_Danhmucsach.Click += new System.EventHandler(this.Quanlysach_Danhmucsach_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Peru;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(71, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(624, 110);
            this.label1.TabIndex = 1;
            this.label1.Text = "WELCOME BACK MANEGER\r\n\r\n";
            // 
            // frmMain_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(762, 545);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmMain_Menu";
            this.Text = "Main Menu";
            this.Load += new System.EventHandler(this.frmMain_Menu_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menu_Quanlynhanvien;
        private System.Windows.Forms.ToolStripMenuItem Quanlynhanvien_Nhanvien;
        private System.Windows.Forms.ToolStripMenuItem Quanlynhanvien_Nhanvien_Thêmnhavien;
        private System.Windows.Forms.ToolStripMenuItem Quanlynhanvien_Nhanvien_Timnhanvien;
        private System.Windows.Forms.ToolStripMenuItem menu_Quanlyhoadon;
        private System.Windows.Forms.ToolStripMenuItem Quanlyhoadon_Hoadon;
        private System.Windows.Forms.ToolStripMenuItem Quanlyhoadon_chitiethoadon;
        private System.Windows.Forms.ToolStripMenuItem menu_Quanlysach;
        private System.Windows.Forms.ToolStripMenuItem Quanlysach_Nhomsach;
        private System.Windows.Forms.ToolStripMenuItem Quanlysach_Danhmucsach;
        private System.Windows.Forms.Label label1;
    }
}