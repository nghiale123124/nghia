﻿using Do_an_mo_hinh_3_lop.BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace Do_an_mo_hinh_3_lop.GUI
{
    public partial class frmTimnhanvien : Form
    {
        public frmTimnhanvien()
        {
            InitializeComponent();
        }

        nhanvien nhanvien;

        private void frmTimnhanvien_Load(object sender, EventArgs e)
        {
            LoadDataTimNhanVien();
        }

        private void btn_Thoat_Click(object sender, EventArgs e)
        {
            DialogResult tb = MessageBox.Show("Ban có muốn thoát form này không?", "Thông Báo!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (tb == DialogResult.Yes)
            {
                this.Close();
            }
        }
        private void LoadDataTimNhanVien()
        {
            DataTable tblNhanVien;
            nhanvien = new nhanvien();
            if (nhanvien.Connect())
            {
                tblNhanVien = nhanvien.GetDataNhanVien();
                dgv_timkiemnhanvien.DataSource = tblNhanVien;
            }
            else
            {
                MessageBox.Show("Kết nối CSDL thất bại", "Thông Báo!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }

            //Dinh dang datagridview
            dgv_timkiemnhanvien.Columns["MaNV"].HeaderText = "MaNV";
            dgv_timkiemnhanvien.Columns["MaNV"].Width = 100;
            dgv_timkiemnhanvien.Columns["HoLot"].HeaderText = "HoLot";
            dgv_timkiemnhanvien.Columns["HoLot"].Width = 200;
            dgv_timkiemnhanvien.Columns["TenNV"].HeaderText = "TenNV";
            dgv_timkiemnhanvien.Columns["TenNV"].Width = 150;
            dgv_timkiemnhanvien.Columns["Phai"].HeaderText = "Phai";
            dgv_timkiemnhanvien.Columns["Phai"].Width = 100;
            dgv_timkiemnhanvien.Columns["NgaySinh"].HeaderText = "NgaySinh";
            dgv_timkiemnhanvien.Columns["NgaySinh"].Width = 100;
            dgv_timkiemnhanvien.Columns["DiaChi"].HeaderText = "DiaChi";
            dgv_timkiemnhanvien.Columns["DiaChi"].Width = 250;
            BindingDataNhanVien();
        }

        private void BindingDataNhanVien()
        {
            //Xoa cac du lieu tren text box
            txt_Timmanhanvien.DataBindings.Clear();
            txt_Timmanhanvien.Focus();
            

            //databinding du lieu tren textbox
            txt_Timmanhanvien.DataBindings.Add("Text", dgv_timkiemnhanvien.DataSource, "MaNV");
            


        }//ket thuc bindingDataNhanVien

        private void btn_Timkiem_Click(object sender, EventArgs e)
        {
            nhanvien = new nhanvien();

            if (txt_Timmanhanvien.TextLength == 0)
            {
                txt_Timmanhanvien.Focus();
                return;
            }

            if (nhanvien.Connect())
            {
                if (nhanvien.CheckMaNV(txt_Timmanhanvien.Text) > 0)
                {
                    LoadDataTimNhanVien_by_MaNV();
                    
                }
                else
                {
                    MessageBox.Show("Không tim thấy MaNV trong CSDL !", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                   
                }
            }
            
        }

        private void LoadDataTimNhanVien_by_MaNV()
        {
            DataTable tblnhanvien;
            nhanvien = new nhanvien();
            if (nhanvien.Connect())
            {
                tblnhanvien = nhanvien.GetDataNhanVien_by_MaNV(txt_Timmanhanvien.Text);
                dgv_timkiemnhanvien.DataSource = tblnhanvien;

            }
            else
            {
                MessageBox.Show("kết nối CSDL thất baị", "Thông báo!");
            }

            dgv_timkiemnhanvien.Columns["MaNV"].HeaderText = "MaNV";
            dgv_timkiemnhanvien.Columns["MaNV"].Width = 100;
            dgv_timkiemnhanvien.Columns["HoLot"].HeaderText = "HoLot";
            dgv_timkiemnhanvien.Columns["HoLot"].Width = 200;
            dgv_timkiemnhanvien.Columns["TenNV"].HeaderText = "TenNV";
            dgv_timkiemnhanvien.Columns["TenNV"].Width = 150;
            dgv_timkiemnhanvien.Columns["Phai"].HeaderText = "Phai";
            dgv_timkiemnhanvien.Columns["Phai"].Width = 100;
            dgv_timkiemnhanvien.Columns["NgaySinh"].HeaderText = "NgaySinh";
            dgv_timkiemnhanvien.Columns["NgaySinh"].Width = 100;
            dgv_timkiemnhanvien.Columns["DiaChi"].HeaderText = "DiaChi";
            dgv_timkiemnhanvien.Columns["DiaChi"].Width = 250;

            BindingDataNhanVien();
        }

        private void dgv_timkiemnhanvien_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            LoadDataTimNhanVien();
        }
    }
}
