﻿using Do_an_mo_hinh_3_lop.BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Do_an_mo_hinh_3_lop.GUI
{
    public partial class frmNhomhang : Form
    {
        public frmNhomhang()
        {
            InitializeComponent();
        }
        Nhomhang nhomsach;
        private void LoadDataNhomSach()
        {
            DataTable tblNhomSach;
            nhomsach = new Nhomhang();
            if (nhomsach.Connect())
            {
                tblNhomSach = nhomsach.GetDatahNhomSach();
                dgv_nhomsach.DataSource = tblNhomSach;
            }
            else
            {
                MessageBox.Show("Kết nối CSDL thất bại", "Thông Báo!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }

            //Dinh dang datagridview
            dgv_nhomsach.Columns["MaNhom"].HeaderText = "MaNhom";
            dgv_nhomsach.Columns["MaNhom"].Width = 200;
            dgv_nhomsach.Columns["TenNhom"].HeaderText = "TenNhom";
            dgv_nhomsach.Columns["TenNhom"].Width = 300;

            BindingDataHoaDon();
        }

        private void BindingDataHoaDon()
        {
            //Xoa cac du lieu tren text box
            txt_MaNhom.DataBindings.Clear();
            txt_TenNhom.DataBindings.Clear();

            //databinding du lieu tren textbox
            txt_MaNhom.DataBindings.Add("Text", dgv_nhomsach.DataSource, "MaNhom");
            txt_TenNhom.DataBindings.Add("Text", dgv_nhomsach.DataSource, "TenNhom");

        }//ket thuc bindingDataNhanVien


        private void frmNhomSach_Load(object sender, EventArgs e)
        {
            LoadDataNhomSach();
        }

        void Trangthainutlenh(string TenNutLenh)
        {
            switch (TenNutLenh)
            {
                case "Thêm":
                    {
                        btnthem.Enabled = false;
                        btnxoa.Enabled = false;
                        btnsua.Enabled = false;
                        btnluu.Enabled = true;
                        txt_MaNhom.ReadOnly = false;
                        txt_MaNhom.Focus();
                        dgv_nhomsach.Enabled = true;
                        break;
                    }
                case "Xóa":
                    {
                        btnthem.Enabled = true;
                        btnxoa.Enabled = false;
                        btnsua.Enabled = false;
                        btnluu.Enabled = false;
                        txt_MaNhom.Focus();

                        break;
                    }
                case "Sửa":
                    {
                        btnthem.Enabled = false;
                        btnxoa.Enabled = false;
                        btnsua.Enabled = false;
                        btnluu.Enabled = true;
                        txt_MaNhom.ReadOnly = true;
                        txt_TenNhom.Focus();
                        dgv_nhomsach.Enabled = false;
                        break;
                    }
                case "Lưu":
                    {
                        btnthem.Enabled = true;
                        btnxoa.Enabled = false;
                        btnsua.Enabled = false;
                        btnluu.Enabled = false;
                        dgv_nhomsach.Enabled = true;
                        break;
                    }
                case "DataGridView":
                    {
                        btnthem.Enabled = true;
                        btnxoa.Enabled = true;
                        btnsua.Enabled = true;
                        btnluu.Enabled = false;
                        break;
                    }
                case "Load":
                    {
                        btnthem.Enabled = true;
                        btnxoa.Enabled = false;
                        btnsua.Enabled = false;
                        btnluu.Enabled = false;
                        break;
                    }

            }
        }//ket thuc trang thai nut lenh

        private void ResetAll()
        {
            txt_MaNhom.Clear();
            txt_MaNhom.Focus();
            txt_TenNhom.Clear();
        }

        private void btnthem_Click(object sender, EventArgs e)
        {
            ResetAll();
            Trangthainutlenh(btnthem.Text);
        }


        private int deleteNhomSach(Nhomhang nhomsach)
        {
            string SqldeleteNhomSach = "delete from NhomSach Where MaNhom=@MaNhom";
            string[] parameters = { "@MaNHom" };
            object[] values = { txt_MaNhom.Text };
            return nhomsach.NhomsachExecuteNonQuery(SqldeleteNhomSach, parameters, values, false);
        }

        private void btnxoa_Click(object sender, EventArgs e)
        {
            nhomsach = new Nhomhang();
            if (nhomsach.Connect())
            {
                DialogResult tb = MessageBox.Show("Ban co chắc muốn xóa dòng dữ liệu này không?", "Thông báo!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (tb == DialogResult.Yes)
                {
                    if (deleteNhomSach(nhomsach) > 0)
                    {
                        MessageBox.Show("Đã Xóa thành công 1 dòng dữ liệu !", "Thông báo!");
                        LoadDataNhomSach();
                        Trangthainutlenh("DataGridView");
                    }

                }
                else
                {
                    Trangthainutlenh("DataGridView");
                    MessageBox.Show("Ban đã hủy xóa thành công!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Vui lòng kiểm tra lại kết nối CSDL", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnsua_Click(object sender, EventArgs e)
        {
            Trangthainutlenh("Sửa");
        }




        private int InsertNhomSach(Nhomhang nhomsach)
        {
            string SqlInsertHoadon = "Insert into NhomSach values (@MaNhom,@TenNhom)";
            string[] parameters = { "@MaNhom", "@TenNhom" };
            object[] values = { txt_MaNhom.Text, txt_TenNhom.Text };
            return nhomsach.NhomsachExecuteNonQuery(SqlInsertHoadon, parameters, values, false);
        }


        private int UpdateNhomSach(Nhomhang nhomsach)
        {
            string SqlUpdateChiTietHoadon = "Update ChiTietHoaDon set TenNhom=@TenNhom where MaNhom=@MaNhom";
            string[] parameters = { "@MaNhom", "@TenNhom" };
            object[] values = { txt_MaNhom.Text, txt_TenNhom.Text };
            return nhomsach.NhomsachExecuteNonQuery(SqlUpdateChiTietHoadon, parameters, values, false);
        }


        bool SaveFlag = true;



        private void btnluu_Click(object sender, EventArgs e)
        {
            nhomsach = new Nhomhang();
            if (nhomsach.Connect())
            {
                if (SaveFlag)
                {
                    if (nhomsach.CheckMaNhom(txt_MaNhom.Text) == 0)
                    {
                        if (InsertNhomSach(nhomsach) > 0)
                        {
                            MessageBox.Show("Đã thêm thành công 1 dữ liệu ", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            LoadDataNhomSach();
                            Trangthainutlenh("DataGridView");
                        }
                        else
                        {
                            Trangthainutlenh("DataGridView");
                            MessageBox.Show("Đã xảy ra lỗi trong quá trình thêm dữ liệu", "Thông bao!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Vui lòng nhập Mã Nhóm Không trùng với CSDL", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                else
                {
                    if (UpdateNhomSach(nhomsach) > 0)
                    {
                        MessageBox.Show("Đã thêm thành công 1 dữ liệu ", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        LoadDataNhomSach();
                        Trangthainutlenh("DataGridView");
                    }
                    else
                    {
                        Trangthainutlenh("DataGridView");
                        MessageBox.Show("Đã xảy ra lỗi trong quá trình thêm dữ liệu", "Thông bao!");
                    }
                }
            }
            else
            {
                MessageBox.Show("Kết nối với CSDL thất bại", "Thông bao!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgv_nhomsach_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            LoadDataNhomSach();
        }

        private void btndong_Click(object sender, EventArgs e)
        {
            DialogResult tb = MessageBox.Show("Bạn có muốn thoát khỏi form này không?", "Thông báo!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (tb == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dgv_nhomsach_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void frmNhomhang_Load(object sender, EventArgs e)
        {
            DataTable tblNhomSach;
            nhomsach = new Nhomhang();
            if (nhomsach.Connect())
            {
                tblNhomSach = nhomsach.GetDatahNhomSach();
                dgv_nhomsach.DataSource = tblNhomSach;
            }
            else
            {
                MessageBox.Show("Kết nối CSDL thất bại", "Thông Báo!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }

            //Dinh dang datagridview
            dgv_nhomsach.Columns["MaNhom"].HeaderText = "MaNhom";
            dgv_nhomsach.Columns["MaNhom"].Width = 200;
            dgv_nhomsach.Columns["TenNhom"].HeaderText = "TenNhom";
            dgv_nhomsach.Columns["TenNhom"].Width = 300;

            BindingDataHoaDon();
        }
    }
}

