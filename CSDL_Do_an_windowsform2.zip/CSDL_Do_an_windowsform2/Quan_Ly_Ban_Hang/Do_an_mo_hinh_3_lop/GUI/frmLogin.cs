﻿using System;
using System.Windows.Forms;
using Do_an_mo_hinh_3_lop.BLL;
using Do_an_mo_hinh_3_lop.GUI;

namespace Do_an_mo_hinh_3_lop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            User user = new User();
            if(txt_UserName.TextLength == 0)//Kiểm tra việc nhập kí tự
            {
                txt_UserName.Focus();
                return;
            }
            if (txtPass.TextLength == 0)
            {
                txtPass.Focus();
                return;
            }

            if (user.Connect())
            {
                if (user.CheckUser(txt_UserName.Text, txtPass.Text) > 0)
                {
                    frmMain_Menu frm = new frmMain_Menu(txt_UserName.Text);
                    frm.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Vui lòng kiểm tra lại tên tài khoản hoặc mật khẩu?", "Thông Báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
            else
            { 
                 MessageBox.Show("Vui lòng kiểm tra kết nối với CSDL ", "Thông Bao!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult thoat = MessageBox.Show("Ban có muốn thoát đăng nhập hay không?", "Thông báo !", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (thoat == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void txt_UserName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((char.IsNumber(e.KeyChar)) || (char.IsPunctuation(e.KeyChar)) || (char.IsSymbol(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void txtPass_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((char.IsLetter(e.KeyChar)) || (char.IsPunctuation(e.KeyChar)) || (char.IsSymbol(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(txtPass.PasswordChar == '*')
            {
                checkBox1.Text = "hiện";
                txtPass.PasswordChar = '\0';
            }
            else
            {
                checkBox1.Text = "ẩn";
                txtPass.PasswordChar = '*';
            }
        }

        private void txt_UserName_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txt_UserName.Text))
            {
                e.Cancel = true;
                txt_UserName.Focus();
                err_username.SetError(txt_UserName, "Vui long nhap user name !");

            }
            else
            {
                e.Cancel = false;
                err_username.SetError(txt_UserName, null);
            }

        }

        private void txtPass_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txt_UserName.Text))
            {
                e.Cancel = true;
                txtPass.Focus();
                errpass.SetError(txtPass, "Vui long nhap Pass Word !");

            }
            else
            {
                e.Cancel = false;
                errpass.SetError(txtPass, null);
            }

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult thoat = MessageBox.Show("Ban có muốn thoát đăng nhập hay không?", "Thông báo !", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (thoat == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btnDangnhap_Click(object sender, EventArgs e)
        {
            User user = new User();
            if (txt_UserName.TextLength == 0)//Kiểm tra việc nhập kí tự
            {
                txt_UserName.Focus();
                return;
            }
            if (txtPass.TextLength == 0)
            {
                txtPass.Focus();
                return;
            }

            if (user.Connect())
            {
                if (user.CheckUser(txt_UserName.Text, txtPass.Text) > 0)
                {
                    frmMain_Menu frm = new frmMain_Menu(txt_UserName.Text);
                    frm.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Vui lòng kiểm tra lại tên tài khoản hoặc mật khẩu?", "Thông Báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
            else
            {
                MessageBox.Show("Vui lòng kiểm tra kết nối với CSDL ", "Thông Bao!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void checkBox1_CheckedChanged_1(object sender, EventArgs e)
        {
            if (txtPass.PasswordChar == '*')
            {
                checkBox1.Text = "hiện";
                txtPass.PasswordChar = '\0';
            }
            else
            {
                checkBox1.Text = "ẩn";
                txtPass.PasswordChar = '*';
            }
        }

        private void txt_UserName_TextChanged(object sender, EventArgs e)
        {
            label5.Visible = false;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtPass_TextChanged(object sender, EventArgs e)
        {
            label2.Visible = false;

        }

        private void backgroundWorker1_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txt_UserName_Click(object sender, EventArgs e)
        {
            txt_UserName.ResetText();
        }
    }
}
