﻿namespace Do_an_mo_hinh_3_lop.GUI
{
    partial class frmChiTietHoaDon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dgv_Bangchitiethoadon = new System.Windows.Forms.DataGridView();
            this.txt_MaHD = new System.Windows.Forms.TextBox();
            this.txt_Masach = new System.Windows.Forms.TextBox();
            this.txt_Soluong = new System.Windows.Forms.TextBox();
            this.btn_dong_Chitiethoadon = new System.Windows.Forms.Button();
            this.btn_luu_Chitiethoadon = new System.Windows.Forms.Button();
            this.btn_Sua_Chitiethoadon = new System.Windows.Forms.Button();
            this.btn_Xoa_Chitiethoadon = new System.Windows.Forms.Button();
            this.btn_them_ChiTiethoadon = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Bangchitiethoadon)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(234, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(368, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Bảng Chi Tiết Hóa Đơn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(96, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ma HD:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(383, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Mã Sách:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(688, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Số Lượng:";
            // 
            // dgv_Bangchitiethoadon
            // 
            this.dgv_Bangchitiethoadon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Bangchitiethoadon.Location = new System.Drawing.Point(95, 178);
            this.dgv_Bangchitiethoadon.Name = "dgv_Bangchitiethoadon";
            this.dgv_Bangchitiethoadon.RowTemplate.Height = 28;
            this.dgv_Bangchitiethoadon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Bangchitiethoadon.Size = new System.Drawing.Size(863, 218);
            this.dgv_Bangchitiethoadon.TabIndex = 4;
            this.dgv_Bangchitiethoadon.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Bangchitiethoadon_CellContentClick);
            // 
            // txt_MaHD
            // 
            this.txt_MaHD.Location = new System.Drawing.Point(190, 101);
            this.txt_MaHD.Name = "txt_MaHD";
            this.txt_MaHD.Size = new System.Drawing.Size(152, 30);
            this.txt_MaHD.TabIndex = 5;
            // 
            // txt_Masach
            // 
            this.txt_Masach.Location = new System.Drawing.Point(495, 101);
            this.txt_Masach.Name = "txt_Masach";
            this.txt_Masach.Size = new System.Drawing.Size(152, 30);
            this.txt_Masach.TabIndex = 6;
            // 
            // txt_Soluong
            // 
            this.txt_Soluong.Location = new System.Drawing.Point(806, 101);
            this.txt_Soluong.Name = "txt_Soluong";
            this.txt_Soluong.Size = new System.Drawing.Size(152, 30);
            this.txt_Soluong.TabIndex = 7;
            // 
            // btn_dong_Chitiethoadon
            // 
            this.btn_dong_Chitiethoadon.Location = new System.Drawing.Point(787, 447);
            this.btn_dong_Chitiethoadon.Name = "btn_dong_Chitiethoadon";
            this.btn_dong_Chitiethoadon.Size = new System.Drawing.Size(135, 48);
            this.btn_dong_Chitiethoadon.TabIndex = 16;
            this.btn_dong_Chitiethoadon.Text = "Đóng";
            this.btn_dong_Chitiethoadon.UseVisualStyleBackColor = true;
            this.btn_dong_Chitiethoadon.Click += new System.EventHandler(this.btn_dong_Chitiethoadon_Click);
            // 
            // btn_luu_Chitiethoadon
            // 
            this.btn_luu_Chitiethoadon.Location = new System.Drawing.Point(614, 447);
            this.btn_luu_Chitiethoadon.Name = "btn_luu_Chitiethoadon";
            this.btn_luu_Chitiethoadon.Size = new System.Drawing.Size(135, 48);
            this.btn_luu_Chitiethoadon.TabIndex = 15;
            this.btn_luu_Chitiethoadon.Text = "Lưu";
            this.btn_luu_Chitiethoadon.UseVisualStyleBackColor = true;
            this.btn_luu_Chitiethoadon.Click += new System.EventHandler(this.btn_luu_Chitiethoadon_Click);
            // 
            // btn_Sua_Chitiethoadon
            // 
            this.btn_Sua_Chitiethoadon.Location = new System.Drawing.Point(441, 447);
            this.btn_Sua_Chitiethoadon.Name = "btn_Sua_Chitiethoadon";
            this.btn_Sua_Chitiethoadon.Size = new System.Drawing.Size(135, 48);
            this.btn_Sua_Chitiethoadon.TabIndex = 14;
            this.btn_Sua_Chitiethoadon.Text = "Sửa";
            this.btn_Sua_Chitiethoadon.UseVisualStyleBackColor = true;
            this.btn_Sua_Chitiethoadon.Click += new System.EventHandler(this.btn_Sua_Chitiethoadon_Click);
            // 
            // btn_Xoa_Chitiethoadon
            // 
            this.btn_Xoa_Chitiethoadon.Location = new System.Drawing.Point(268, 447);
            this.btn_Xoa_Chitiethoadon.Name = "btn_Xoa_Chitiethoadon";
            this.btn_Xoa_Chitiethoadon.Size = new System.Drawing.Size(135, 48);
            this.btn_Xoa_Chitiethoadon.TabIndex = 13;
            this.btn_Xoa_Chitiethoadon.Text = "Xóa";
            this.btn_Xoa_Chitiethoadon.UseVisualStyleBackColor = true;
            this.btn_Xoa_Chitiethoadon.Click += new System.EventHandler(this.btn_Xoa_Chitiethoadon_Click);
            // 
            // btn_them_ChiTiethoadon
            // 
            this.btn_them_ChiTiethoadon.Location = new System.Drawing.Point(95, 447);
            this.btn_them_ChiTiethoadon.Name = "btn_them_ChiTiethoadon";
            this.btn_them_ChiTiethoadon.Size = new System.Drawing.Size(135, 48);
            this.btn_them_ChiTiethoadon.TabIndex = 12;
            this.btn_them_ChiTiethoadon.Text = "Thêm";
            this.btn_them_ChiTiethoadon.UseVisualStyleBackColor = true;
            this.btn_them_ChiTiethoadon.Click += new System.EventHandler(this.btn_them_ChiTiethoadon_Click);
            // 
            // frmChiTietHoaDon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1017, 520);
            this.Controls.Add(this.btn_dong_Chitiethoadon);
            this.Controls.Add(this.btn_luu_Chitiethoadon);
            this.Controls.Add(this.btn_Sua_Chitiethoadon);
            this.Controls.Add(this.btn_Xoa_Chitiethoadon);
            this.Controls.Add(this.btn_them_ChiTiethoadon);
            this.Controls.Add(this.txt_Soluong);
            this.Controls.Add(this.txt_Masach);
            this.Controls.Add(this.txt_MaHD);
            this.Controls.Add(this.dgv_Bangchitiethoadon);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Blue;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmChiTietHoaDon";
            this.Text = "Chi Tiết Hóa Đơn";
            this.Load += new System.EventHandler(this.frmChiTietHoaDon_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Bangchitiethoadon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dgv_Bangchitiethoadon;
        private System.Windows.Forms.TextBox txt_MaHD;
        private System.Windows.Forms.TextBox txt_Masach;
        private System.Windows.Forms.TextBox txt_Soluong;
        private System.Windows.Forms.Button btn_dong_Chitiethoadon;
        private System.Windows.Forms.Button btn_luu_Chitiethoadon;
        private System.Windows.Forms.Button btn_Sua_Chitiethoadon;
        private System.Windows.Forms.Button btn_Xoa_Chitiethoadon;
        private System.Windows.Forms.Button btn_them_ChiTiethoadon;
    }
}