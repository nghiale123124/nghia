﻿using System;
using System.Data;
using System.Data.SqlClient;
using Do_an_mo_hinh_3_lop.DAL;
namespace Do_an_mo_hinh_3_lop.BLL
{
    class nhanvien
    {
        Providers providers = new Providers();

        public SqlConnection Connection()
        {
            return providers.conn;
        }

        public Boolean Connect()
        {
            return providers.Connect();
        }

        public void DisConnect()
        {
            providers.DisConnect();
        }

        public DataTable GetDataNhanVien()
        {
            string[] Parameters = { };
            string[] Values = { };
            return providers.GetData("Select * from NhanVien", Parameters, Values, false);
        }

        public int NhanVienExecuteNonQuery(string queryOrSpName,string[] Parameters,object[] Values,bool isStored)
        {
            return providers.ExecuteNonQuery(queryOrSpName, Parameters, Values, isStored);
        }

       

        public DataTable GetDataNhanVien_by_MaNV(string MaNV)
        {
            string[] Parameters = { "@MaNV" };
            string[] Values = { MaNV };
            return providers.GetData("Select * from NhanVien where MaNV=@MaNV", Parameters, Values, false);
        }


        public int CheckMaNV(string MaNV)
        {
            providers.Connect();
            string strsql = "Select count(*) from NhanVien where MaNV=@MaNV";
            SqlCommand cmd = new SqlCommand(strsql, Connection());
            SqlParameter timMaNV = new SqlParameter("@MaNV", MaNV);
            cmd.Parameters.Add(timMaNV);
            int kqsql = (int)cmd.ExecuteScalar();
            return kqsql;
        }


        public int CheckMaNVTrongHD(string MaNV)
        {
            providers.Connect();
            string strsql1 = "Select count(*) from HoaDon where MaNV=@MaNV";
            SqlCommand cmd1 = new SqlCommand(strsql1, Connection());
            SqlParameter timMaNVtrongHD = new SqlParameter("@MaNV", MaNV);
            cmd1.Parameters.Add(timMaNVtrongHD);
            int kqsql1 = (int)cmd1.ExecuteScalar();
            return kqsql1;
        }

    }
}
