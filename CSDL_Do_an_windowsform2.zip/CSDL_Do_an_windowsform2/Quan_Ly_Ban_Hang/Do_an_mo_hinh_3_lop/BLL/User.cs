﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// them thu viên
using System.Data.SqlClient;
using Do_an_mo_hinh_3_lop.DAL;
using System.Data;

namespace Do_an_mo_hinh_3_lop.BLL
{
    class User
    {
        //khai Báo và tạo đối tượng providers
        Providers providers = new Providers();

        public SqlConnection Connection()
        {
            return providers.conn;
        }// ket thuc phần kết nối

        public Boolean Connect()
        {
            return providers.Connect();
        }// kết thúc phần Connect

        //viết hàm xử lý ngắt kết nối

        public void DisConnect()
        {
            providers.DisConnect();
        }//kết thúc phần DisConnect(ngắt kết nối)

        //viết hàm check user và password có 2 tham so la tài khoan và mật khẩu

        public int CheckUser(string User,string Pass)
        {
            providers.Connect();
            string strsql = "Select count(*) from Users where ((TenTk=@TaiKhoan) and (MatKhau=@MatKhauNguoiDung))";
            SqlCommand cmd = new SqlCommand(strsql,Connection());
            SqlParameter para1 = new SqlParameter("@TaiKhoan", User); ;
            SqlParameter para2 = new SqlParameter("@MatKhauNguoiDung", Pass);
            cmd.Parameters.Add(para1);
            cmd.Parameters.Add(para2);

            int kqsql = (int)cmd.ExecuteScalar();
            return kqsql;
        }

    }
}
