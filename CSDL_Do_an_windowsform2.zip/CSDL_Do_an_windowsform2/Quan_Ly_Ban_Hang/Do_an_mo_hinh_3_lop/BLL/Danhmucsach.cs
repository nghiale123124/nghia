﻿using Do_an_mo_hinh_3_lop.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Do_an_mo_hinh_3_lop.BLL
{
    class Danhmucsach
    {

        Providers providers = new Providers();

        public SqlConnection Connection()
        {
            return providers.conn;
        }// ket thuc phần kết nối

        public Boolean Connect()
        {
            return providers.Connect();
        }// kết thúc phần Connect

        //viết hàm xử lý ngắt kết nối

        public void DisConnect()
        {
            providers.DisConnect();
        }//kết thúc phần DisConnect(ngắt kết nối)
        public DataTable GetDatahDanhMucSach()
        {
            string[] Parameters = { };
            string[] Values = { };
            return providers.GetData("Select * from DanhMucSach", Parameters, Values, false);
        }


        public DataTable GetData()
        {
            string[] Parameters = { };
            string[] Values = { };
            return providers.GetData("Select * from DanhMucSach", Parameters, Values, false);
        }

        public int DanhmucSachExecuteNonQuery(string queryOrSpName, string[] Parameters, object[] Values, bool isStored)
        {
            return providers.ExecuteNonQuery(queryOrSpName, Parameters, Values, isStored);
        }

        public int CheckManhom(string manhom)
        {
            providers.Connect();
            string strsql = "Select count(*) from NhomSach where MaNhom=@MaNhom";
            SqlCommand cmd = new SqlCommand(strsql, Connection());
            SqlParameter para1 = new SqlParameter("@MaNhom", manhom); ;
            cmd.Parameters.Add(para1);
            int kqsql = (int)cmd.ExecuteScalar();
            return kqsql;
        }

        public int CheckMa(string manhom)
        {
            providers.Connect();
            string strsql = "Select count(*) from NhomSach where MaNhom=@MaNhom";
            SqlCommand cmd = new SqlCommand(strsql, Connection());
            SqlParameter para1 = new SqlParameter("@MaNhom", manhom); ;
            cmd.Parameters.Add(para1);
            int kqsql = (int)cmd.ExecuteScalar();
            return kqsql;
        }
    }
}
