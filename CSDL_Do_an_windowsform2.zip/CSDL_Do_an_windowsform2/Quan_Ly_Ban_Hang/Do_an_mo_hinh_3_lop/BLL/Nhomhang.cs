﻿using Do_an_mo_hinh_3_lop.DAL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Do_an_mo_hinh_3_lop.BLL
{
    internal class Nhomhang
    {
        Providers providers = new Providers();

        public SqlConnection Connection()
        {
            return providers.conn;
        }// ket thuc phần kết nối

        public Boolean Connect()
        {
            return providers.Connect();
        }// kết thúc phần Connect

        //viết hàm xử lý ngắt kết nối

        public void DisConnect()
        {
            providers.DisConnect();
        }//kết thúc phần DisConnect(ngắt kết nối)
        public DataTable GetDatahNhomSach()
        {
            string[] Parameters = { };
            string[] Values = { };
            return providers.GetData("Select * from NhomSach", Parameters, Values, false);
        }


        public DataTable GetData()
        {
            string[] Parameters = { };
            string[] Values = { };
            return providers.GetData("Select * from NhomSach", Parameters, Values, false);
        }

        public int NhomsachExecuteNonQuery(string queryOrSpName, string[] Parameters, object[] Values, bool isStored)
        {
            return providers.ExecuteNonQuery(queryOrSpName, Parameters, Values, isStored);
        }

        public int CheckMaNhom(string MaNhom)
        {
            providers.Connect();
            string strsqlMaNhom = "Select count(*) from NhomSach where MaNhom=@MaNhom";
            SqlCommand cmd = new SqlCommand(strsqlMaNhom, Connection());
            SqlParameter manhom = new SqlParameter("@MaNhom", MaNhom);
            cmd.Parameters.Add(manhom);
            int kqsqlMaNhom = (int)cmd.ExecuteScalar();
            return kqsqlMaNhom;
        }
    }
}
