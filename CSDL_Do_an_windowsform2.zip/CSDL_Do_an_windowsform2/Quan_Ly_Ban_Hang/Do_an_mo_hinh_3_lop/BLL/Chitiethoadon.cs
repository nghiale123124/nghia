﻿using Do_an_mo_hinh_3_lop.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Do_an_mo_hinh_3_lop.BLL
{
    class Chitiethoadon
    {
        Providers providers = new Providers();

        public SqlConnection Connection()
        {
            return providers.conn;
        }// ket thuc phần kết nối

        public Boolean Connect()
        {
            return providers.Connect();
        }// kết thúc phần Connect

        //viết hàm xử lý ngắt kết nối

        public void DisConnect()
        {
            providers.DisConnect();
        }//kết thúc phần DisConnect(ngắt kết nối)

        //hàm check MaHD nếu người dùng nhâp MaHD khác với MAHD chứa khóa chính trong CSDl
        public int CheckMaHD(string MaHD)
        {
            providers.Connect();
            string strsql = "Select count(*) from HoaDon where MaHD=@MaHD";
            SqlCommand cmd = new SqlCommand(strsql, Connection());
            SqlParameter timMaHD = new SqlParameter("@MaHD", MaHD);
            cmd.Parameters.Add(timMaHD);
            int kqsql = (int)cmd.ExecuteScalar();
            return kqsql;
        }

        public int CheckMaSach(string MaSach)
        {
            providers.Connect();
            string strsql = "Select count(*) from DanhMucSach where MaSach=@MaSach";
            SqlCommand cmd = new SqlCommand(strsql, Connection());
            SqlParameter timMaSach = new SqlParameter("@MaSach", MaSach);
            cmd.Parameters.Add(timMaSach);
            int kqsql1 = (int)cmd.ExecuteScalar();
            return kqsql1;
        }

        public DataTable GetDataChitiethoadon()
        {
            string[] Parameters = { };
            string[] Values = { };
            return providers.GetData("Select * from ChiTietHoaDon", Parameters, Values, false);
        }

        public int ChiTietHoadonExecuteNonQuery(string queryOrSpName, string[] Parameters, object[] Values, bool isStored)
        {
            return providers.ExecuteNonQuery(queryOrSpName, Parameters, Values, isStored);
        }
    }
}
