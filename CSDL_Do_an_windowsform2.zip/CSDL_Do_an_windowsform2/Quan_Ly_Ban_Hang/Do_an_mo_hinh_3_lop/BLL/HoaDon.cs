﻿using Do_an_mo_hinh_3_lop.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Do_an_mo_hinh_3_lop.BLL
{
    class HoaDon
    {
        Providers providers = new Providers();

        public SqlConnection Connection()
        {
            return providers.conn;
        }// ket thuc phần kết nối

        public Boolean Connect()
        {
            return providers.Connect();
        }// kết thúc phần Connect

        //viết hàm xử lý ngắt kết nối

        public void DisConnect()
        {
            providers.DisConnect();
        }//kết thúc phần DisConnect(ngắt kết nối)

        //hàm check MaNV nếu người dùng nhâp MaNV khác với MANV chứa khóa chính trong CSDl
        public int CheckMaNV(string MaNV)
        {
            providers.Connect();
            string strsql = "Select count(*) from NhanVien where MaNV=@MaNV";
            SqlCommand cmd = new SqlCommand(strsql, Connection());
            SqlParameter timMaNV = new SqlParameter("@MaNV", MaNV);
            cmd.Parameters.Add(timMaNV);
            int kqsql = (int)cmd.ExecuteScalar();
            return kqsql;
        }

        public int CheckHD(string MaHD)
        {
            providers.Connect();
            string strsql = "Select count(*) from HoaDon where MaHD=@MaHD";
            SqlCommand cmd = new SqlCommand(strsql, Connection());
            SqlParameter CheckMaHD = new SqlParameter("@MaHD", MaHD);
            cmd.Parameters.Add(CheckMaHD);
            int kqsqlhd = (int)cmd.ExecuteScalar();
            return kqsqlhd;
        }

        public DataTable GetDataHoadon()
        {
            string[] Parameters = { };
            string[] Values = { };
            return providers.GetData("Select * from HoaDon", Parameters, Values, false);
        }

        public int HoadonExecuteNonQuery(string queryOrSpName, string[] Parameters, object[] Values, bool isStored)
        {
            return providers.ExecuteNonQuery(queryOrSpName, Parameters, Values, isStored);
        }
    }
}
